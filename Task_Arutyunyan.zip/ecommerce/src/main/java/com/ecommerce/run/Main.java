package com.ecommerce.run;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.FileReadException;
import com.ecommerce.exception.OrderException;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.logging.AppLogger;
import com.ecommerce.observer.AnalyticsObserver;
import com.ecommerce.observer.CustomerNotificationObserver;
import com.ecommerce.observer.OrderEventPublisher;
import com.ecommerce.observer.WarehouseObserver;
import com.ecommerce.proxy.CachingProductRepositoryProxy;
import com.ecommerce.proxy.RealProductRepository;
import com.ecommerce.reader.OrderFileReader;
import com.ecommerce.service.OrderService;
import com.ecommerce.strategy.delivery.DigitalDeliveryStrategy;
import com.ecommerce.strategy.delivery.ExpressDeliveryStrategy;
import com.ecommerce.strategy.delivery.StandardDeliveryStrategy;
import com.ecommerce.strategy.payment.CreditCardPaymentStrategy;
import com.ecommerce.strategy.payment.CryptoPaymentStrategy;
import com.ecommerce.strategy.payment.PayPalPaymentStrategy;

import java.util.List;
import java.util.logging.Logger;

/**
 * Точка входа в систему обработки заказов интернет-магазина.
 *
 * <p>Демонстрирует все реализованные паттерны:
 * <ul>
 *   <li>Фабричный метод  — создание заказов из файла</li>
 *   <li>Стратегия        — стратегии оплаты и доставки</li>
 *   <li>Наблюдатель      — уведомления при смене статуса</li>
 *   <li>Цепочка обязанностей — конвейер валидации</li>
 *   <li>Прокси           — кэш товаров</li>
 * </ul>
 */
public class Main {

    private static final Logger LOG = AppLogger.getLogger(Main.class);

    public static void main(String[] args) {
        LOG.info("=== Запуск системы обработки заказов интернет-магазина ===");

        // --- Прокси: инициализация кэшированного репозитория товаров ---
        RealProductRepository realRepo = new RealProductRepository();
        CachingProductRepositoryProxy cachedRepo = new CachingProductRepositoryProxy(realRepo);
        LOG.info("Репозиторий товаров с кэш-прокси инициализирован. "
                + "Размер кэша: " + cachedRepo.getCacheSize());

        // --- Наблюдатель: подписка всех слушателей ---
        OrderEventPublisher publisher = new OrderEventPublisher();
        publisher.subscribe(new CustomerNotificationObserver());
        publisher.subscribe(new WarehouseObserver());
        publisher.subscribe(new AnalyticsObserver());
        LOG.info("Подписано наблюдателей: " + publisher.getObserverCount()
                + " (покупатель, склад, аналитика)");

        // --- Сервис заказов ---
        OrderService service = new OrderService(publisher);

        // --- Фабричный метод + чтение файла ---
        LOG.info("--- Шаг 1: Чтение заказов из файла ---");
        OrderFileReader reader = new OrderFileReader();
        List<Order> orders;
        try {
            orders = reader.readFromClasspath("data/orders.txt");
        } catch (FileReadException e) {
            LOG.severe("Не удалось прочитать файл заказов: " + e.getMessage());
            return;
        }

        if (orders.isEmpty()) {
            LOG.warning("Файл не содержит корректных заказов. Завершение работы.");
            return;
        }

        // --- Стратегия + Цепочка + Наблюдатель: обработка заказов ---
        LOG.info("--- Шаг 2: Обработка заказов (" + orders.size() + " шт.) ---");

        for (Order order : orders) {
            try {
                switch (order.getOrderType()) {
                    case REGULAR:
                        service.processOrder(
                                order,
                                new CreditCardPaymentStrategy("4111111111111111",
                                        order.getCustomer().getName()),
                                new StandardDeliveryStrategy());
                        break;

                    case PRE_ORDER:
                        service.processOrder(
                                order,
                                new PayPalPaymentStrategy(order.getCustomer().getEmail()),
                                new DigitalDeliveryStrategy());
                        break;

                    case SUBSCRIPTION:
                        service.processOrder(
                                order,
                                new CryptoPaymentStrategy("0xABCDEF1234567890ABCD", "ETH"),
                                new ExpressDeliveryStrategy());
                        break;

                    default:
                        LOG.warning("Неизвестный тип заказа, пропускается: "
                                + order.getOrderType());
                }
            } catch (ValidationException e) {
                LOG.warning("Заказ " + order.getOrderId()
                        + " отклонён валидатором: " + e.getMessage());
                service.cancelOrder(order);
            } catch (PaymentException e) {
                LOG.warning("Заказ " + order.getOrderId()
                        + " — ошибка оплаты: " + e.getMessage());
                service.cancelOrder(order);
            } catch (OrderException e) {
                LOG.severe("Заказ " + order.getOrderId()
                        + " — критическая ошибка: " + e.getMessage());
                service.cancelOrder(order);
            }
        }

        // --- Итоговая статистика ---
        long shipped   = orders.stream()
                .filter(o -> o.getStatus().name().equals("SHIPPED")).count();
        long cancelled = orders.stream()
                .filter(o -> o.getStatus().name().equals("CANCELLED")).count();

        LOG.info("--- Шаг 3: Итоги ---");
        LOG.info("Всего заказов обработано : " + orders.size());
        LOG.info("Отправлено               : " + shipped);
        LOG.info("Отменено                 : " + cancelled);
        LOG.info("Размер кэша товаров      : " + cachedRepo.getCacheSize());
        LOG.info("=== Работа системы завершена ===");
    }
}
