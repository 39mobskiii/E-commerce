package com.ecommerce.chain;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Обработчик цепочки: проверяет корректность адреса доставки.
 */
public class AddressValidationHandler extends AbstractValidationHandler {

    private static final Logger LOG = AppLogger.getLogger(AddressValidationHandler.class);

    @Override
    protected void doValidate(Order order) throws ValidationException {
        String address = order.getCustomer().getAddress();
        if (address == null || address.trim().isEmpty()) {
            throw new ValidationException(
                    "Адрес доставки не указан для заказа " + order.getOrderId());
        }
        if (address.trim().length() < 10) {
            throw new ValidationException(
                    "Адрес доставки слишком короткий (минимум 10 символов): «"
                            + address + "» (заказ " + order.getOrderId() + ")");
        }
        LOG.info("Проверка адреса доставки пройдена — заказ " + order.getOrderId()
                + ", адрес: " + address);
    }
}
