package com.ecommerce.chain;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.ValidationException;

/**
 * Abstract base for chain-of-responsibility validators.
 * Handles chaining and delegates to subclass for actual validation logic.
 */
public abstract class AbstractValidationHandler implements ValidationHandler {

    private ValidationHandler next;

    @Override
    public ValidationHandler setNext(ValidationHandler next) {
        this.next = next;
        return next;
    }

    /**
     * Runs this handler's check, then forwards to the next handler if present.
     *
     * @param order the order to validate
     * @throws ValidationException if this or a subsequent check fails
     */
    @Override
    public void validate(Order order) throws ValidationException {
        doValidate(order);
        if (next != null) {
            next.validate(order);
        }
    }

    /**
     * Performs the specific validation step.
     *
     * @param order the order to validate
     * @throws ValidationException if validation fails
     */
    protected abstract void doValidate(Order order) throws ValidationException;
}
