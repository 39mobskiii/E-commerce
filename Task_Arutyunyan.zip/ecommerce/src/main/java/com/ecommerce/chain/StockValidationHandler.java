package com.ecommerce.chain;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.Product;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Обработчик цепочки: проверяет наличие товаров на складе.
 */
public class StockValidationHandler extends AbstractValidationHandler {

    private static final Logger LOG = AppLogger.getLogger(StockValidationHandler.class);

    @Override
    protected void doValidate(Order order) throws ValidationException {
        for (Product product : order.getProducts()) {
            if (product.getStockQuantity() <= 0) {
                throw new ValidationException(
                        "Товар отсутствует на складе: «" + product.getName()
                                + "» (арт. " + product.getId() + ")");
            }
        }
        LOG.info("Проверка наличия товаров пройдена — заказ " + order.getOrderId());
    }
}
