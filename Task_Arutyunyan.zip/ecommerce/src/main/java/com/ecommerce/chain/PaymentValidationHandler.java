package com.ecommerce.chain;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Обработчик цепочки: проверяет корректность оплаты заказа.
 */
public class PaymentValidationHandler extends AbstractValidationHandler {

    private static final Logger LOG = AppLogger.getLogger(PaymentValidationHandler.class);

    @Override
    protected void doValidate(Order order) throws ValidationException {
        if (order.getPaymentMethod() == null || order.getPaymentMethod().isEmpty()) {
            throw new ValidationException(
                    "Не указан способ оплаты для заказа " + order.getOrderId());
        }
        if (order.getTotalAmount() <= 0) {
            throw new ValidationException(
                    "Сумма заказа должна быть положительной, получено: "
                            + order.getTotalAmount() + " (заказ " + order.getOrderId() + ")");
        }
        LOG.info("Проверка оплаты пройдена — заказ " + order.getOrderId()
                + ", способ: " + order.getPaymentMethod());
    }
}
