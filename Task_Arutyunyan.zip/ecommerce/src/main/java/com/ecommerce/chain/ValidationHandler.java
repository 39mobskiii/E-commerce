package com.ecommerce.chain;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.ValidationException;

/**
 * Chain of Responsibility handler interface for order validation.
 * Each handler performs one validation step and delegates to the next.
 */
public interface ValidationHandler {

    /**
     * Sets the next handler in the chain.
     *
     * @param next the next handler
     * @return the next handler (for fluent chaining)
     */
    ValidationHandler setNext(ValidationHandler next);

    /**
     * Validates the order and delegates to the next handler if validation passes.
     *
     * @param order the order to validate
     * @throws ValidationException if validation fails
     */
    void validate(Order order) throws ValidationException;
}
