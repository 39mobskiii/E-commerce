package com.ecommerce.factory;

import com.ecommerce.entity.OrderType;
import com.ecommerce.exception.OrderException;

/**
 * Provider that resolves the correct OrderFactory based on order type.
 */
public class OrderFactoryProvider {

    /**
     * Returns the factory corresponding to the given order type.
     *
     * @param type the order type
     * @return matching OrderFactory
     * @throws OrderException if the type is unknown
     */
    public OrderFactory getFactory(OrderType type) throws OrderException {
        switch (type) {
            case REGULAR:
                return new RegularOrderFactory();
            case PRE_ORDER:
                return new PreOrderFactory();
            case SUBSCRIPTION:
                return new SubscriptionFactory();
            default:
                throw new OrderException("Unknown order type: " + type);
        }
    }
}
