package com.ecommerce.factory;

import com.ecommerce.entity.Customer;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderType;
import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Factory Method implementation for creating regular orders.
 */
public class RegularOrderFactory implements OrderFactory {

    @Override
    public Order createOrder(String orderId, Customer customer, List<Product> products,
                             String... params) throws OrderException {
        if (orderId == null || orderId.isEmpty()) {
            throw new OrderException("Order ID must not be null or empty");
        }
        if (customer == null) {
            throw new OrderException("Customer must not be null");
        }
        if (products == null || products.isEmpty()) {
            throw new OrderException("Products list must not be null or empty");
        }
        return new Order(orderId, customer, products, OrderType.REGULAR, LocalDateTime.now());
    }
}
