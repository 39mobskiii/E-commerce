package com.ecommerce.factory;

import com.ecommerce.entity.Customer;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.Subscription;
import com.ecommerce.exception.OrderException;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Factory Method implementation for creating subscription orders.
 * Requires intervalDays and renewalsLeft as extra parameters.
 */
public class SubscriptionFactory implements OrderFactory {

    @Override
    public Order createOrder(String orderId, Customer customer, List<Product> products,
                             String... params) throws OrderException {
        if (orderId == null || orderId.isEmpty()) {
            throw new OrderException("Order ID must not be null or empty");
        }
        if (customer == null) {
            throw new OrderException("Customer must not be null");
        }
        if (products == null || products.isEmpty()) {
            throw new OrderException("Products list must not be null or empty");
        }
        if (params == null || params.length < 2) {
            throw new OrderException("Subscription requires intervalDays and renewalsLeft parameters");
        }

        int intervalDays;
        int renewalsLeft;
        try {
            intervalDays = Integer.parseInt(params[0]);
            renewalsLeft = Integer.parseInt(params[1]);
        } catch (NumberFormatException e) {
            throw new OrderException("Invalid numeric parameters for Subscription: "
                    + params[0] + ", " + params[1], e);
        }

        if (intervalDays <= 0) {
            throw new OrderException("intervalDays must be positive, got: " + intervalDays);
        }
        if (renewalsLeft < 0) {
            throw new OrderException("renewalsLeft must be non-negative, got: " + renewalsLeft);
        }

        return new Subscription(orderId, customer, products,
                LocalDateTime.now(), intervalDays, renewalsLeft);
    }
}
