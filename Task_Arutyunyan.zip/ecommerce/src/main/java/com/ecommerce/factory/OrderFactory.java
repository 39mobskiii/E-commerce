package com.ecommerce.factory;

import com.ecommerce.entity.Customer;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;

import java.util.List;

/**
 * Factory Method interface for creating different types of orders.
 * Each concrete factory creates a specific order subtype.
 */
public interface OrderFactory {

    /**
     * Creates an order with the given parameters.
     *
     * @param orderId   unique order identifier
     * @param customer  the customer placing the order
     * @param products  list of products in the order
     * @param params    additional type-specific parameters
     * @return a new Order instance
     * @throws OrderException if creation fails due to invalid parameters
     */
    Order createOrder(String orderId, Customer customer, List<Product> products,
                      String... params) throws OrderException;
}
