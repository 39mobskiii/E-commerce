package com.ecommerce.factory;

import com.ecommerce.entity.Customer;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.PreOrder;
import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Factory Method implementation for creating pre-orders.
 * Requires an availability date as the first extra parameter.
 */
public class PreOrderFactory implements OrderFactory {

    @Override
    public Order createOrder(String orderId, Customer customer, List<Product> products,
                             String... params) throws OrderException {
        if (orderId == null || orderId.isEmpty()) {
            throw new OrderException("Order ID must not be null or empty");
        }
        if (customer == null) {
            throw new OrderException("Customer must not be null");
        }
        if (products == null || products.isEmpty()) {
            throw new OrderException("Products list must not be null or empty");
        }
        if (params == null || params.length < 1) {
            throw new OrderException("PreOrder requires availableFrom date parameter");
        }

        LocalDateTime availableFrom;
        try {
            availableFrom = LocalDateTime.parse(params[0]);
        } catch (Exception e) {
            throw new OrderException("Invalid availableFrom date format: " + params[0], e);
        }

        return new PreOrder(orderId, customer, products, LocalDateTime.now(), availableFrom);
    }
}
