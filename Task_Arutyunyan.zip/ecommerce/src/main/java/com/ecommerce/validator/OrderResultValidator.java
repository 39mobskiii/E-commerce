package com.ecommerce.validator;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.ValidationException;

/**
 * Validates computed results on orders (e.g. total amount after calculation).
 */
public class OrderResultValidator {

    private static final double MAX_ORDER_TOTAL = 1_000_000.0;

    /**
     * Validates that the computed total for an order is within acceptable bounds.
     *
     * @param order the order whose total to validate
     * @throws ValidationException if the total is invalid
     */
    public void validateOrderTotal(Order order) throws ValidationException {
        if (order == null) {
            throw new ValidationException("Order must not be null");
        }
        double total = order.getTotalAmount();
        if (total <= 0) {
            throw new ValidationException(
                    "Order total must be positive, got: " + total
                            + " for order " + order.getOrderId());
        }
        if (total > MAX_ORDER_TOTAL) {
            throw new ValidationException(
                    "Order total exceeds maximum allowed (" + MAX_ORDER_TOTAL + "): "
                            + total + " for order " + order.getOrderId());
        }
    }

    /**
     * Validates that the order has a customer and at least one product.
     *
     * @param order the order to check
     * @throws ValidationException if essential data is missing
     */
    public void validateOrderCompleteness(Order order) throws ValidationException {
        if (order == null) {
            throw new ValidationException("Order must not be null");
        }
        if (order.getCustomer() == null) {
            throw new ValidationException("Order " + order.getOrderId() + " has no customer");
        }
        if (order.getProducts() == null || order.getProducts().isEmpty()) {
            throw new ValidationException(
                    "Order " + order.getOrderId() + " has no products");
        }
    }
}
