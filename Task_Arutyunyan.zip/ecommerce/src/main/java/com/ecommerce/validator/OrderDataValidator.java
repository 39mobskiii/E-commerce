package com.ecommerce.validator;

import com.ecommerce.exception.ValidationException;

/**
 * Validates raw string data read from input files before creating entities.
 */
public class OrderDataValidator {

    private static final int MIN_ORDER_ID_LENGTH = 3;
    private static final int MIN_NAME_LENGTH = 2;
    private static final double MIN_PRICE = 0.01;
    private static final int MIN_ADDRESS_LENGTH = 10;

    /**
     * Validates an order ID string.
     *
     * @param orderId the order ID to validate
     * @throws ValidationException if invalid
     */
    public void validateOrderId(String orderId) throws ValidationException {
        if (orderId == null || orderId.trim().isEmpty()) {
            throw new ValidationException("Order ID must not be blank");
        }
        if (orderId.trim().length() < MIN_ORDER_ID_LENGTH) {
            throw new ValidationException(
                    "Order ID too short (min " + MIN_ORDER_ID_LENGTH + "): " + orderId);
        }
    }

    /**
     * Validates a customer name.
     *
     * @param name the customer name
     * @throws ValidationException if invalid
     */
    public void validateCustomerName(String name) throws ValidationException {
        if (name == null || name.trim().isEmpty()) {
            throw new ValidationException("Customer name must not be blank");
        }
        if (name.trim().length() < MIN_NAME_LENGTH) {
            throw new ValidationException(
                    "Customer name too short (min " + MIN_NAME_LENGTH + "): " + name);
        }
    }

    /**
     * Validates an email address.
     *
     * @param email the email to validate
     * @throws ValidationException if invalid
     */
    public void validateEmail(String email) throws ValidationException {
        if (email == null || email.trim().isEmpty()) {
            throw new ValidationException("Email must not be blank");
        }
        if (!email.contains("@") || !email.contains(".")) {
            throw new ValidationException("Invalid email format: " + email);
        }
    }

    /**
     * Validates a delivery address.
     *
     * @param address the address string
     * @throws ValidationException if invalid
     */
    public void validateAddress(String address) throws ValidationException {
        if (address == null || address.trim().isEmpty()) {
            throw new ValidationException("Address must not be blank");
        }
        if (address.trim().length() < MIN_ADDRESS_LENGTH) {
            throw new ValidationException(
                    "Address too short (min " + MIN_ADDRESS_LENGTH + "): " + address);
        }
    }

    /**
     * Validates a product price parsed from a string.
     *
     * @param priceStr the price string
     * @return the parsed price
     * @throws ValidationException if invalid
     */
    public double validateAndParsePrice(String priceStr) throws ValidationException {
        if (priceStr == null || priceStr.trim().isEmpty()) {
            throw new ValidationException("Price must not be blank");
        }
        double price;
        try {
            price = Double.parseDouble(priceStr.trim());
        } catch (NumberFormatException e) {
            throw new ValidationException("Invalid price value: " + priceStr);
        }
        if (price < MIN_PRICE) {
            throw new ValidationException(
                    "Price must be at least " + MIN_PRICE + ", got: " + price);
        }
        return price;
    }

    /**
     * Validates and parses a non-negative integer from a string.
     *
     * @param value     the string to parse
     * @param fieldName the name of the field (for error messages)
     * @return the parsed integer
     * @throws ValidationException if invalid
     */
    public int validateAndParsePositiveInt(String value, String fieldName)
            throws ValidationException {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException(fieldName + " must not be blank");
        }
        int parsed;
        try {
            parsed = Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            throw new ValidationException("Invalid integer for " + fieldName + ": " + value);
        }
        if (parsed < 0) {
            throw new ValidationException(fieldName + " must be non-negative, got: " + parsed);
        }
        return parsed;
    }

    /**
     * Validates and parses an order type string.
     *
     * @param typeStr the type string (e.g. "REGULAR")
     * @return the parsed type
     * @throws ValidationException if invalid
     */
    public com.ecommerce.entity.OrderType validateAndParseOrderType(String typeStr)
            throws ValidationException {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            throw new ValidationException("Order type must not be blank");
        }
        try {
            return com.ecommerce.entity.OrderType.valueOf(typeStr.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ValidationException("Unknown order type: " + typeStr);
        }
    }
}
