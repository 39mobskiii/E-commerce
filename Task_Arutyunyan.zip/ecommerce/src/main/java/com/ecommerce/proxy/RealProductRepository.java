package com.ecommerce.proxy;

import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;
import com.ecommerce.logging.AppLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Реальная реализация репозитория товаров на основе Map (эмулирует БД).
 */
public class RealProductRepository implements ProductRepository {

    private static final Logger LOG = AppLogger.getLogger(RealProductRepository.class);

    private final Map<String, Product> storage = new HashMap<>();

    @Override
    public Product findById(String productId) throws OrderException {
        LOG.fine("БД: запрос товара с идентификатором «" + productId + "»");
        Product product = storage.get(productId);
        if (product == null) {
            throw new OrderException("Товар не найден: " + productId);
        }
        return product;
    }

    @Override
    public void save(Product product) {
        if (product != null) {
            storage.put(product.getId(), product);
            LOG.fine("БД: товар сохранён — " + product.getId());
        }
    }
}
