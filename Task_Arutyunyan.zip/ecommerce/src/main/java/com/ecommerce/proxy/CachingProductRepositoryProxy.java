package com.ecommerce.proxy;

import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;
import com.ecommerce.logging.AppLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Прокси-кэш для репозитория товаров.
 * Возвращает товар из кэша при повторных запросах, избегая обращений к БД.
 */
public class CachingProductRepositoryProxy implements ProductRepository {

    private static final Logger LOG = AppLogger.getLogger(CachingProductRepositoryProxy.class);

    private final ProductRepository realRepository;
    private final Map<String, Product> cache = new HashMap<>();

    public CachingProductRepositoryProxy(ProductRepository realRepository) {
        this.realRepository = realRepository;
    }

    @Override
    public Product findById(String productId) throws OrderException {
        if (cache.containsKey(productId)) {
            LOG.info("Кэш: товар найден в кэше — «" + productId + "»");
            return cache.get(productId);
        }
        Product product = realRepository.findById(productId);
        cache.put(productId, product);
        LOG.info("Кэш: товар загружен из БД и добавлен в кэш — «" + productId + "»");
        return product;
    }

    @Override
    public void save(Product product) {
        realRepository.save(product);
        if (product != null) {
            cache.put(product.getId(), product);
            LOG.fine("Кэш: товар сохранён в БД и кэше — «" + product.getId() + "»");
        }
    }

    /**
     * Инвалидирует конкретный товар в кэше.
     *
     * @param productId идентификатор товара
     */
    public void invalidate(String productId) {
        cache.remove(productId);
        LOG.info("Кэш: запись удалена — «" + productId + "»");
    }

    /**
     * Полностью очищает кэш.
     */
    public void clearCache() {
        cache.clear();
        LOG.info("Кэш: полностью очищен");
    }

    public int getCacheSize() {
        return cache.size();
    }
}
