package com.ecommerce.proxy;

import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;

/**
 * Interface for accessing product data.
 * Implemented by the real service and the caching proxy.
 */
public interface ProductRepository {

    /**
     * Finds a product by its ID.
     *
     * @param productId the product identifier
     * @return the found product
     * @throws OrderException if the product does not exist
     */
    Product findById(String productId) throws OrderException;

    /**
     * Saves or updates a product in the repository.
     *
     * @param product the product to save
     */
    void save(Product product);
}
