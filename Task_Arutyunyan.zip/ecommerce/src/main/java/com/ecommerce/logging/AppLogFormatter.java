package com.ecommerce.logging;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * Форматтер логов приложения.
 * Выводит строки вида: 2026-05-22 14:03:01 | INFO  | ИмяКласса | Сообщение
 */
public class AppLogFormatter extends Formatter {

    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public String format(LogRecord record) {
        String timestamp = LocalDateTime.now().format(DATE_FMT);
        String level = formatLevel(record.getLevel());
        String source = shortSource(record.getLoggerName());
        String message = formatMessage(record);

        StringBuilder sb = new StringBuilder();
        sb.append(timestamp)
          .append(" | ").append(level)
          .append(" | ").append(source)
          .append(" | ").append(message)
          .append(System.lineSeparator());

        if (record.getThrown() != null) {
            sb.append("    Причина: ")
              .append(record.getThrown().getMessage())
              .append(System.lineSeparator());
        }

        return sb.toString();
    }

    private String formatLevel(Level level) {
        if (level == Level.SEVERE)  return "ОШИБКА";
        if (level == Level.WARNING) return "ПРЕДУПР";
        if (level == Level.INFO)    return "ИНФО   ";
        if (level == Level.FINE)    return "ОТЛАДКА";
        return level.getName();
    }

    private String shortSource(String loggerName) {
        if (loggerName == null) {
            return "Приложение";
        }
        // Берём только последнюю часть имени пакета (имя класса)
        int dot = loggerName.lastIndexOf('.');
        return dot >= 0 ? loggerName.substring(dot + 1) : loggerName;
    }
}
