package com.ecommerce.logging;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * Утилита для получения настроенного логгера.
 * Загружает конфигурацию из logging.properties при первом обращении.
 */
public final class AppLogger {

    private static volatile boolean configured = false;

    private AppLogger() {
    }

    /**
     * Возвращает логгер для указанного класса.
     *
     * @param clazz класс, для которого создаётся логгер
     * @return настроенный логгер
     */
    public static Logger getLogger(Class<?> clazz) {
        ensureConfigured();
        return Logger.getLogger(clazz.getName());
    }

    private static void ensureConfigured() {
        if (configured) {
            return;
        }
        synchronized (AppLogger.class) {
            if (configured) {
                return;
            }
            try (InputStream in = AppLogger.class
                    .getClassLoader()
                    .getResourceAsStream("logging.properties")) {
                if (in != null) {
                    LogManager.getLogManager().readConfiguration(in);
                }
            } catch (IOException e) {
                Logger.getLogger(AppLogger.class.getName())
                      .warning("Не удалось загрузить logging.properties: " + e.getMessage());
            }
            configured = true;
        }
    }
}
