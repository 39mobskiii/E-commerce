package com.ecommerce.logging;

import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;

/**
 * Handler, который пишет логи в System.out (а не в System.err).
 * Благодаря этому вывод в терминале не красится в красный цвет.
 */
public class StdoutHandler extends StreamHandler {

    public StdoutHandler() {
        super(System.out, new AppLogFormatter());
        setLevel(java.util.logging.Level.ALL);
    }

    @Override
    public void publish(LogRecord record) {
        super.publish(record);
        flush(); // сразу сбрасываем буфер, чтобы строки не задерживались
    }

    @Override
    public void close() {
        flush(); // не закрываем System.out
    }
}
