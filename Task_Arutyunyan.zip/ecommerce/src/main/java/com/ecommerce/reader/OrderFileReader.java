package com.ecommerce.reader;

import com.ecommerce.entity.Customer;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderType;
import com.ecommerce.entity.Product;
import com.ecommerce.exception.FileReadException;
import com.ecommerce.exception.OrderException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.factory.OrderFactory;
import com.ecommerce.factory.OrderFactoryProvider;
import com.ecommerce.logging.AppLogger;
import com.ecommerce.validator.OrderDataValidator;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Stream;

/**
 * Читает данные заказов из текстового файла с использованием Java 8 NIO / Streams API.
 *
 * <p>Формат строки (поля разделены точкой с запятой):
 * <pre>
 * ТИП;НОМЕР_ЗАКАЗА;ИД_КЛИЕНТА;ИМЯ;EMAIL;АДРЕС;АРТ:НАЗВАНИЕ:ЦЕНА:ОСТАТОК[,...];[ДОППАРАМЕТРЫ]
 * </pre>
 *
 * <p>Некорректные строки пропускаются с предупреждением в лог.
 */
public class OrderFileReader {

    private static final Logger LOG = AppLogger.getLogger(OrderFileReader.class);

    private static final String SEPARATOR = ";";
    private static final String PRODUCT_SEPARATOR = ",";
    private static final String PRODUCT_FIELD_SEPARATOR = ":";
    private static final int MIN_FIELDS = 7;

    private final OrderDataValidator validator;
    private final OrderFactoryProvider factoryProvider;

    public OrderFileReader() {
        this.validator = new OrderDataValidator();
        this.factoryProvider = new OrderFactoryProvider();
    }

    /**
     * Читает заказы из ресурса в classpath.
     *
     * @param resourcePath путь относительно корня classpath (например, "data/orders.txt")
     * @return список успешно разобранных заказов
     * @throws FileReadException если файл не найден или не может быть открыт
     */
    public List<Order> readFromClasspath(String resourcePath) throws FileReadException {
        URL resource = getClass().getClassLoader().getResource(resourcePath);
        if (resource == null) {
            throw new FileReadException("Ресурс не найден в classpath: " + resourcePath);
        }
        Path path;
        try {
            path = Paths.get(resource.toURI());
        } catch (URISyntaxException e) {
            throw new FileReadException("Некорректный URI для ресурса: " + resourcePath, e);
        }
        return readFromPath(path);
    }

    /**
     * Читает заказы из файла по заданному пути.
     *
     * @param filePath путь к файлу
     * @return список успешно разобранных заказов
     * @throws FileReadException если файл не существует или возникла ошибка чтения
     */
    public List<Order> readFromPath(Path filePath) throws FileReadException {
        if (!Files.exists(filePath)) {
            throw new FileReadException("Файл не найден: " + filePath);
        }

        LOG.info("Начало чтения файла заказов: " + filePath);
        List<Order> orders = new ArrayList<>();

        try (Stream<String> lines = Files.lines(filePath)) {
            lines
                .filter(line -> !line.isBlank())
                .filter(line -> !line.startsWith("#"))
                .forEach(line -> {
                    try {
                        Order order = parseLine(line.trim());
                        orders.add(order);
                        LOG.info("Заказ загружен: " + order.getOrderId()
                                + " [" + order.getOrderType() + "]");
                    } catch (OrderException e) {
                        LOG.warning("Строка пропущена (некорректные данные): "
                                + e.getMessage() + " | Строка: «" + line.trim() + "»");
                    }
                });
        } catch (IOException e) {
            throw new FileReadException("Ошибка чтения файла: " + filePath, e);
        }

        LOG.info("Чтение завершено: загружено " + orders.size() + " заказ(ов) из файла " + filePath.getFileName());
        return orders;
    }

    private Order parseLine(String line) throws OrderException {
        String[] fields = line.split(SEPARATOR, -1);

        if (fields.length < MIN_FIELDS) {
            throw new ValidationException(
                    "Недостаточно полей: ожидалось минимум " + MIN_FIELDS
                            + ", получено " + fields.length);
        }

        String typeStr     = fields[0].trim();
        String orderId     = fields[1].trim();
        String custId      = fields[2].trim();
        String custName    = fields[3].trim();
        String email       = fields[4].trim();
        String address     = fields[5].trim();
        String productsStr = fields[6].trim();

        OrderType orderType = validator.validateAndParseOrderType(typeStr);
        validator.validateOrderId(orderId);
        validator.validateCustomerName(custName);
        validator.validateEmail(email);
        validator.validateAddress(address);

        Customer customer = new Customer(custId, custName, email, address);
        List<Product> products = parseProducts(productsStr);

        String[] extraParams = Arrays.copyOfRange(fields, 7, fields.length);

        OrderFactory factory = factoryProvider.getFactory(orderType);
        return factory.createOrder(orderId, customer, products, extraParams);
    }

    private List<Product> parseProducts(String productsStr) throws ValidationException {
        if (productsStr == null || productsStr.isEmpty()) {
            throw new ValidationException("Поле товаров пустое");
        }

        List<Product> products = new ArrayList<>();
        String[] productTokens = productsStr.split(PRODUCT_SEPARATOR);

        for (String token : productTokens) {
            String[] parts = token.trim().split(PRODUCT_FIELD_SEPARATOR);
            if (parts.length < 4) {
                throw new ValidationException(
                        "Некорректный формат товара (ожидается арт:название:цена:остаток): " + token);
            }
            String productId   = parts[0].trim();
            String productName = parts[1].trim();
            double price  = validator.validateAndParsePrice(parts[2].trim());
            int    stock  = validator.validateAndParsePositiveInt(parts[3].trim(), "остаток");

            products.add(new Product(productId, productName, price, stock));
        }

        if (products.isEmpty()) {
            throw new ValidationException("Ни одного товара не распознано из: " + productsStr);
        }

        return products;
    }
}
