package com.ecommerce.entity;

/**
 * Represents the lifecycle status of an order.
 */
public enum OrderStatus {
    CREATED,
    PENDING_PAYMENT,
    PAYMENT_CONFIRMED,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
