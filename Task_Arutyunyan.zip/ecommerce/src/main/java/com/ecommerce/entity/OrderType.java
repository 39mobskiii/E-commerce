package com.ecommerce.entity;

/**
 * Represents the type of an order in the system.
 */
public enum OrderType {
    REGULAR,
    PRE_ORDER,
    SUBSCRIPTION
}
