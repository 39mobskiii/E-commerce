package com.ecommerce.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Base entity representing an order in the e-commerce system.
 * Does not contain business logic — only data.
 */
public class Order {

    private final String orderId;
    private final Customer customer;
    private final List<Product> products;
    private final OrderType orderType;
    private OrderStatus status;
    private final LocalDateTime createdAt;
    private String paymentMethod;
    private String deliveryMethod;
    private double totalAmount;

    public Order(String orderId, Customer customer, List<Product> products,
                 OrderType orderType, LocalDateTime createdAt) {
        this.orderId = orderId;
        this.customer = customer;
        this.products = new ArrayList<>(products);
        this.orderType = orderType;
        this.createdAt = createdAt;
        this.status = OrderStatus.CREATED;
    }

    public String getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<Product> getProducts() {
        return new ArrayList<>(products);
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {
        return "Order{"
                + "orderId='" + orderId + '\''
                + ", customer=" + customer
                + ", products=" + products
                + ", orderType=" + orderType
                + ", status=" + status
                + ", createdAt=" + createdAt
                + ", paymentMethod='" + paymentMethod + '\''
                + ", deliveryMethod='" + deliveryMethod + '\''
                + ", totalAmount=" + totalAmount
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Order order = (Order) o;
        return (orderId != null ? orderId.equals(order.orderId) : order.orderId == null)
                && orderType == order.orderType;
    }

    @Override
    public int hashCode() {
        int result = orderId != null ? orderId.hashCode() : 0;
        result = 31 * result + (orderType != null ? orderType.hashCode() : 0);
        return result;
    }
}
