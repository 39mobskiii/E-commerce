package com.ecommerce.entity;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Represents a pre-order — placed before the product is available.
 */
public class PreOrder extends Order {

    private final LocalDateTime availableFrom;

    public PreOrder(String orderId, Customer customer, List<Product> products,
                    LocalDateTime createdAt, LocalDateTime availableFrom) {
        super(orderId, customer, products, OrderType.PRE_ORDER, createdAt);
        this.availableFrom = availableFrom;
    }

    public LocalDateTime getAvailableFrom() {
        return availableFrom;
    }

    @Override
    public String toString() {
        return "PreOrder{"
                + "orderId='" + getOrderId() + '\''
                + ", customer=" + getCustomer()
                + ", availableFrom=" + availableFrom
                + ", status=" + getStatus()
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (!super.equals(o)) {
            return false;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        PreOrder preOrder = (PreOrder) o;
        return availableFrom != null
                ? availableFrom.equals(preOrder.availableFrom)
                : preOrder.availableFrom == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (availableFrom != null ? availableFrom.hashCode() : 0);
        return result;
    }
}
