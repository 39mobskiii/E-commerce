package com.ecommerce.entity;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Represents a subscription order that recurs on a defined interval.
 */
public class Subscription extends Order {

    private final int intervalDays;
    private final int renewalsLeft;

    public Subscription(String orderId, Customer customer, List<Product> products,
                        LocalDateTime createdAt, int intervalDays, int renewalsLeft) {
        super(orderId, customer, products, OrderType.SUBSCRIPTION, createdAt);
        this.intervalDays = intervalDays;
        this.renewalsLeft = renewalsLeft;
    }

    public int getIntervalDays() {
        return intervalDays;
    }

    public int getRenewalsLeft() {
        return renewalsLeft;
    }

    @Override
    public String toString() {
        return "Subscription{"
                + "orderId='" + getOrderId() + '\''
                + ", customer=" + getCustomer()
                + ", intervalDays=" + intervalDays
                + ", renewalsLeft=" + renewalsLeft
                + ", status=" + getStatus()
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (!super.equals(o)) {
            return false;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        Subscription that = (Subscription) o;
        return intervalDays == that.intervalDays && renewalsLeft == that.renewalsLeft;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + intervalDays;
        result = 31 * result + renewalsLeft;
        return result;
    }
}
