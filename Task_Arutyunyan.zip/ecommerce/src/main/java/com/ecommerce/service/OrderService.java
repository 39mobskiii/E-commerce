package com.ecommerce.service;

import com.ecommerce.chain.AddressValidationHandler;
import com.ecommerce.chain.PaymentValidationHandler;
import com.ecommerce.chain.StockValidationHandler;
import com.ecommerce.chain.ValidationHandler;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.logging.AppLogger;
import com.ecommerce.observer.OrderEventPublisher;
import com.ecommerce.strategy.delivery.DeliveryStrategy;
import com.ecommerce.strategy.payment.PaymentStrategy;
import com.ecommerce.validator.OrderResultValidator;

import java.util.logging.Logger;

/**
 * Главный сервис обработки заказов.
 * Координирует Factory, Strategy, Observer, Chain of Responsibility и Proxy.
 */
public class OrderService {

    private static final Logger LOG = AppLogger.getLogger(OrderService.class);

    private final OrderEventPublisher publisher;
    private final OrderResultValidator resultValidator;

    public OrderService(OrderEventPublisher publisher) {
        this.publisher = publisher;
        this.resultValidator = new OrderResultValidator();
    }

    /**
     * Полная обработка заказа: расчёт суммы, оплата, валидация, доставка.
     *
     * @param order            обрабатываемый заказ
     * @param paymentStrategy  стратегия оплаты
     * @param deliveryStrategy стратегия доставки
     * @throws OrderException      при общей ошибке обработки
     * @throws ValidationException при провале валидации
     * @throws PaymentException    при ошибке оплаты
     */
    public void processOrder(Order order, PaymentStrategy paymentStrategy,
                             DeliveryStrategy deliveryStrategy)
            throws OrderException, ValidationException, PaymentException {

        LOG.info("Начало обработки заказа " + order.getOrderId()
                + " [" + order.getOrderType() + "]");

        // 1. Расчёт итоговой суммы
        double total = calculateTotal(order, deliveryStrategy);
        order.setTotalAmount(total);
        LOG.info("Сумма заказа " + order.getOrderId() + " рассчитана: " + total + " руб."
                + " (товары + доставка «" + deliveryStrategy.getMethodName() + "»)");

        // 2. Смена статуса — ожидание оплаты
        updateStatus(order, OrderStatus.PENDING_PAYMENT);

        // 3. Оплата (Стратегия)
        paymentStrategy.pay(order);
        updateStatus(order, OrderStatus.PAYMENT_CONFIRMED);

        // 4. Цепочка валидации
        ValidationHandler chain = buildValidationChain();
        chain.validate(order);

        // 5. Проверка результата вычислений
        resultValidator.validateOrderTotal(order);
        resultValidator.validateOrderCompleteness(order);

        // 6. Доставка (Стратегия)
        updateStatus(order, OrderStatus.PROCESSING);
        deliveryStrategy.deliver(order);

        // 7. Заказ отправлен
        updateStatus(order, OrderStatus.SHIPPED);

        LOG.info("Заказ " + order.getOrderId() + " успешно обработан. Итог: "
                + order.getTotalAmount() + " руб.");
    }

    /**
     * Отменяет заказ и уведомляет наблюдателей.
     *
     * @param order отменяемый заказ
     */
    public void cancelOrder(Order order) {
        LOG.warning("Заказ " + order.getOrderId() + " отменён.");
        updateStatus(order, OrderStatus.CANCELLED);
    }

    private double calculateTotal(Order order, DeliveryStrategy deliveryStrategy) {
        double productTotal = order.getProducts().stream()
                .mapToDouble(Product::getPrice)
                .sum();
        return productTotal + deliveryStrategy.getDeliveryCost();
    }

    private void updateStatus(Order order, OrderStatus newStatus) {
        order.setStatus(newStatus);
        publisher.notifyObservers(order, newStatus);
    }

    private ValidationHandler buildValidationChain() {
        StockValidationHandler stockHandler = new StockValidationHandler();
        PaymentValidationHandler paymentHandler = new PaymentValidationHandler();
        AddressValidationHandler addressHandler = new AddressValidationHandler();
        // Наличие → Оплата → Адрес
        stockHandler.setNext(paymentHandler).setNext(addressHandler);
        return stockHandler;
    }
}
