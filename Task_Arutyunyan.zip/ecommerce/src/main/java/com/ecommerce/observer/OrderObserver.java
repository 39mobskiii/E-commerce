package com.ecommerce.observer;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderStatus;

/**
 * Observer interface for receiving notifications about order status changes.
 * Part of the Observer pattern implementation.
 */
public interface OrderObserver {

    /**
     * Called when an order's status changes.
     *
     * @param order     the order that changed
     * @param newStatus the new status of the order
     */
    void onStatusChanged(Order order, OrderStatus newStatus);
}
