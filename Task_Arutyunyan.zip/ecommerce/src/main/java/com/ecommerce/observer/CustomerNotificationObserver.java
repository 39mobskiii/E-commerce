package com.ecommerce.observer;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Наблюдатель: уведомляет покупателя по e-mail об изменении статуса заказа.
 */
public class CustomerNotificationObserver implements OrderObserver {

    private static final Logger LOG = AppLogger.getLogger(CustomerNotificationObserver.class);

    @Override
    public void onStatusChanged(Order order, OrderStatus newStatus) {
        LOG.info("Уведомление покупателю «" + order.getCustomer().getName()
                + "» (e-mail: " + order.getCustomer().getEmail()
                + "): заказ " + order.getOrderId()
                + " — новый статус: " + russianStatus(newStatus));
    }

    private String russianStatus(OrderStatus status) {
        switch (status) {
            case CREATED:            return "Создан";
            case PENDING_PAYMENT:    return "Ожидает оплаты";
            case PAYMENT_CONFIRMED:  return "Оплата подтверждена";
            case PROCESSING:         return "В обработке";
            case SHIPPED:            return "Отправлен";
            case DELIVERED:          return "Доставлен";
            case CANCELLED:          return "Отменён";
            default:                 return status.name();
        }
    }
}
