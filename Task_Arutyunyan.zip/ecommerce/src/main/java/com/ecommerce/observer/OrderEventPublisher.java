package com.ecommerce.observer;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages subscribers and publishes order status change events to all observers.
 */
public class OrderEventPublisher {

    private final List<OrderObserver> observers = new ArrayList<>();

    /**
     * Registers an observer to receive order events.
     *
     * @param observer the observer to add
     */
    public void subscribe(OrderObserver observer) {
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }

    /**
     * Removes an observer from the subscription list.
     *
     * @param observer the observer to remove
     */
    public void unsubscribe(OrderObserver observer) {
        observers.remove(observer);
    }

    /**
     * Notifies all registered observers about an order status change.
     *
     * @param order     the order whose status changed
     * @param newStatus the new status
     */
    public void notifyObservers(Order order, OrderStatus newStatus) {
        for (OrderObserver observer : observers) {
            observer.onStatusChanged(order, newStatus);
        }
    }

    public int getObserverCount() {
        return observers.size();
    }
}
