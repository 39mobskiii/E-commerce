package com.ecommerce.observer;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Наблюдатель: уведомляет склад о необходимости подготовить или отменить отгрузку.
 */
public class WarehouseObserver implements OrderObserver {

    private static final Logger LOG = AppLogger.getLogger(WarehouseObserver.class);

    @Override
    public void onStatusChanged(Order order, OrderStatus newStatus) {
        if (newStatus == OrderStatus.PAYMENT_CONFIRMED) {
            LOG.info("Склад: начать сборку заказа " + order.getOrderId()
                    + " — " + order.getProducts().size() + " позиция(й)");
        } else if (newStatus == OrderStatus.CANCELLED) {
            LOG.info("Склад: вернуть товары на полку по отменённому заказу " + order.getOrderId());
        } else {
            LOG.fine("Склад: получено обновление статуса заказа " + order.getOrderId()
                    + " → " + newStatus);
        }
    }
}
