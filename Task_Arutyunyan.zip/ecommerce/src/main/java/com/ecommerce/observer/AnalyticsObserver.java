package com.ecommerce.observer;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Наблюдатель: фиксирует события заказов для системы аналитики.
 */
public class AnalyticsObserver implements OrderObserver {

    private static final Logger LOG = AppLogger.getLogger(AnalyticsObserver.class);

    @Override
    public void onStatusChanged(Order order, OrderStatus newStatus) {
        LOG.info("Аналитика: событие зафиксировано — заказ=" + order.getOrderId()
                + ", тип=" + order.getOrderType()
                + ", статус=" + newStatus
                + ", сумма=" + order.getTotalAmount() + " руб.");
    }
}
