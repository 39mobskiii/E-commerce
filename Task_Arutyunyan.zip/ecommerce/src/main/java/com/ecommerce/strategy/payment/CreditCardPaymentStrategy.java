package com.ecommerce.strategy.payment;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Стратегия оплаты банковской картой.
 */
public class CreditCardPaymentStrategy implements PaymentStrategy {

    private static final Logger LOG = AppLogger.getLogger(CreditCardPaymentStrategy.class);
    private static final String METHOD_NAME = "CreditCard";

    private final String cardNumber;
    private final String cardHolder;

    public CreditCardPaymentStrategy(String cardNumber, String cardHolder) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
    }

    @Override
    public void pay(Order order) throws PaymentException {
        if (order == null) {
            throw new PaymentException("Невозможно обработать оплату: заказ равен null");
        }
        if (cardNumber == null || cardNumber.length() < 13) {
            throw new PaymentException("Некорректный номер банковской карты");
        }
        order.setPaymentMethod(METHOD_NAME);
        LOG.info("Списано " + order.getTotalAmount() + " руб. с карты "
                + maskCard() + " по заказу " + order.getOrderId());
    }

    @Override
    public String getMethodName() {
        return METHOD_NAME;
    }

    private String maskCard() {
        return "****-****-****-" + cardNumber.substring(cardNumber.length() - 4);
    }
}
