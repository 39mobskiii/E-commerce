package com.ecommerce.strategy.delivery;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.OrderException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Стратегия экспресс-доставки (следующий рабочий день).
 */
public class ExpressDeliveryStrategy implements DeliveryStrategy {

    private static final Logger LOG = AppLogger.getLogger(ExpressDeliveryStrategy.class);
    private static final String METHOD_NAME = "Экспресс";
    private static final double COST = 19.99;

    @Override
    public void deliver(Order order) throws OrderException {
        if (order == null) {
            throw new OrderException("Невозможно оформить доставку: заказ равен null");
        }
        order.setDeliveryMethod(METHOD_NAME);
        LOG.info("Заказ " + order.getOrderId() + " будет доставлен на следующий рабочий день по адресу: "
                + order.getCustomer().getAddress());
    }

    @Override
    public double getDeliveryCost() {
        return COST;
    }

    @Override
    public String getMethodName() {
        return METHOD_NAME;
    }
}
