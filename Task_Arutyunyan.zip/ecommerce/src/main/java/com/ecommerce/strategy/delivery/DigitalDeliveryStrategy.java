package com.ecommerce.strategy.delivery;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.OrderException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Стратегия электронной доставки — отправка ссылки на скачивание по e-mail.
 */
public class DigitalDeliveryStrategy implements DeliveryStrategy {

    private static final Logger LOG = AppLogger.getLogger(DigitalDeliveryStrategy.class);
    private static final String METHOD_NAME = "Электронная";
    private static final double COST = 0.0;

    @Override
    public void deliver(Order order) throws OrderException {
        if (order == null) {
            throw new OrderException("Невозможно оформить доставку: заказ равен null");
        }
        order.setDeliveryMethod(METHOD_NAME);
        LOG.info("Ссылка для скачивания отправлена на " + order.getCustomer().getEmail()
                + " по заказу " + order.getOrderId());
    }

    @Override
    public double getDeliveryCost() {
        return COST;
    }

    @Override
    public String getMethodName() {
        return METHOD_NAME;
    }
}
