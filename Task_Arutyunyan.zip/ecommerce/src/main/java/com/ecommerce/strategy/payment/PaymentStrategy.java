package com.ecommerce.strategy.payment;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.PaymentException;

/**
 * Strategy interface for processing payments.
 * Implementations define concrete payment methods.
 */
public interface PaymentStrategy {

    /**
     * Processes payment for the given order.
     *
     * @param order the order to pay for
     * @throws PaymentException if the payment cannot be processed
     */
    void pay(Order order) throws PaymentException;

    /**
     * Returns the human-readable name of this payment method.
     *
     * @return payment method name
     */
    String getMethodName();
}
