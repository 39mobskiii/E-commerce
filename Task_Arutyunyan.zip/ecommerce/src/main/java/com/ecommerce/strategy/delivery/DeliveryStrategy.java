package com.ecommerce.strategy.delivery;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.OrderException;

/**
 * Strategy interface for delivering orders.
 * Implementations represent different shipping methods.
 */
public interface DeliveryStrategy {

    /**
     * Arranges delivery for the given order.
     *
     * @param order the order to deliver
     * @throws OrderException if delivery cannot be arranged
     */
    void deliver(Order order) throws OrderException;

    /**
     * Returns the cost of this delivery method.
     *
     * @return delivery cost
     */
    double getDeliveryCost();

    /**
     * Returns the human-readable name of this delivery method.
     *
     * @return delivery method name
     */
    String getMethodName();
}
