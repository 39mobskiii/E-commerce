package com.ecommerce.strategy.payment;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Стратегия оплаты через PayPal.
 */
public class PayPalPaymentStrategy implements PaymentStrategy {

    private static final Logger LOG = AppLogger.getLogger(PayPalPaymentStrategy.class);
    private static final String METHOD_NAME = "PayPal";

    private final String email;

    public PayPalPaymentStrategy(String email) {
        this.email = email;
    }

    @Override
    public void pay(Order order) throws PaymentException {
        if (order == null) {
            throw new PaymentException("Невозможно обработать оплату: заказ равен null");
        }
        if (email == null || !email.contains("@")) {
            throw new PaymentException("Некорректный адрес PayPal: " + email);
        }
        order.setPaymentMethod(METHOD_NAME);
        LOG.info("Списано " + order.getTotalAmount() + " руб. с аккаунта PayPal "
                + email + " по заказу " + order.getOrderId());
    }

    @Override
    public String getMethodName() {
        return METHOD_NAME;
    }
}
