package com.ecommerce.strategy.payment;

import com.ecommerce.entity.Order;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.logging.AppLogger;

import java.util.logging.Logger;

/**
 * Стратегия оплаты криптовалютой.
 */
public class CryptoPaymentStrategy implements PaymentStrategy {

    private static final Logger LOG = AppLogger.getLogger(CryptoPaymentStrategy.class);
    private static final String METHOD_NAME = "Crypto";

    private final String walletAddress;
    private final String currency;

    public CryptoPaymentStrategy(String walletAddress, String currency) {
        this.walletAddress = walletAddress;
        this.currency = currency;
    }

    @Override
    public void pay(Order order) throws PaymentException {
        if (order == null) {
            throw new PaymentException("Невозможно обработать оплату: заказ равен null");
        }
        if (walletAddress == null || walletAddress.length() < 10) {
            throw new PaymentException("Некорректный адрес криптокошелька");
        }
        if (currency == null || currency.isEmpty()) {
            throw new PaymentException("Необходимо указать криптовалюту");
        }
        order.setPaymentMethod(METHOD_NAME + "-" + currency);
        LOG.info("Списано " + order.getTotalAmount() + " " + currency
                + " на кошелёк " + walletAddress + " по заказу " + order.getOrderId());
    }

    @Override
    public String getMethodName() {
        return METHOD_NAME;
    }
}
