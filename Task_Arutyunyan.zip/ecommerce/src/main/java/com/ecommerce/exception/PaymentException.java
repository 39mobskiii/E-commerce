package com.ecommerce.exception;

/**
 * Exception thrown when a payment operation fails.
 */
public class PaymentException extends OrderException {

    public PaymentException(String message) {
        super(message);
    }

    public PaymentException(String message, Throwable cause) {
        super(message, cause);
    }
}
