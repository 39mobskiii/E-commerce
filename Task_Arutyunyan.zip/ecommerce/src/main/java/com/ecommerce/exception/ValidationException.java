package com.ecommerce.exception;

/**
 * Exception thrown when order or data validation fails.
 */
public class ValidationException extends OrderException {

    public ValidationException(String message) {
        super(message);
    }

    public ValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
