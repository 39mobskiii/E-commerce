package com.ecommerce.exception;

/**
 * Exception thrown when reading order data from file fails.
 */
public class FileReadException extends OrderException {

    public FileReadException(String message) {
        super(message);
    }

    public FileReadException(String message, Throwable cause) {
        super(message, cause);
    }
}
