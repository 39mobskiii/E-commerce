package com.ecommerce.exception;

/**
 * Base exception for the e-commerce order processing system.
 */
public class OrderException extends Exception {

    public OrderException(String message) {
        super(message);
    }

    public OrderException(String message, Throwable cause) {
        super(message, cause);
    }
}
