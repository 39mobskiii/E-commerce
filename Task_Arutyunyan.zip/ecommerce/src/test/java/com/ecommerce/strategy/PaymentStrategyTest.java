package com.ecommerce.strategy;

import com.ecommerce.entity.*;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.strategy.payment.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PaymentStrategyTest {

    private Order order;

    @BeforeEach
    void setUp() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 10));
        order = new Order("ORD-1", customer, products, OrderType.REGULAR, LocalDateTime.now());
        order.setTotalAmount(29.99);
    }

    // --- CreditCard ---

    @Test
    void creditCardPaySetsPaymentMethod() throws PaymentException {
        PaymentStrategy strategy = new CreditCardPaymentStrategy("4111111111111111", "Alice Smith");
        strategy.pay(order);
        assertEquals("CreditCard", order.getPaymentMethod());
    }

    @Test
    void creditCardReturnsCorrectMethodName() {
        PaymentStrategy strategy = new CreditCardPaymentStrategy("4111111111111111", "Alice");
        assertEquals("CreditCard", strategy.getMethodName());
    }

    @Test
    void creditCardThrowsOnNullOrder() {
        PaymentStrategy strategy = new CreditCardPaymentStrategy("4111111111111111", "Alice");
        assertThrows(PaymentException.class, () -> strategy.pay(null));
    }

    @Test
    void creditCardThrowsOnInvalidCardNumber() {
        PaymentStrategy strategy = new CreditCardPaymentStrategy("123", "Alice");
        assertThrows(PaymentException.class, () -> strategy.pay(order));
    }

    // --- PayPal ---

    @Test
    void paypalPaySetsPaymentMethod() throws PaymentException {
        PaymentStrategy strategy = new PayPalPaymentStrategy("alice@paypal.com");
        strategy.pay(order);
        assertEquals("PayPal", order.getPaymentMethod());
    }

    @Test
    void paypalReturnsCorrectMethodName() {
        assertEquals("PayPal", new PayPalPaymentStrategy("a@b.com").getMethodName());
    }

    @Test
    void paypalThrowsOnNullOrder() {
        PaymentStrategy strategy = new PayPalPaymentStrategy("a@b.com");
        assertThrows(PaymentException.class, () -> strategy.pay(null));
    }

    @Test
    void paypalThrowsOnInvalidEmail() {
        PaymentStrategy strategy = new PayPalPaymentStrategy("not-an-email");
        assertThrows(PaymentException.class, () -> strategy.pay(order));
    }

    // --- Crypto ---

    @Test
    void cryptoPaySetsPaymentMethod() throws PaymentException {
        PaymentStrategy strategy = new CryptoPaymentStrategy(
                "0xABCDEF1234567890", "ETH");
        strategy.pay(order);
        assertTrue(order.getPaymentMethod().startsWith("Crypto"));
    }

    @Test
    void cryptoReturnsCorrectMethodName() {
        assertEquals("Crypto",
                new CryptoPaymentStrategy("0xABCDEF1234567890", "BTC").getMethodName());
    }

    @Test
    void cryptoThrowsOnNullOrder() {
        PaymentStrategy strategy = new CryptoPaymentStrategy("0xABCDEF1234567890", "ETH");
        assertThrows(PaymentException.class, () -> strategy.pay(null));
    }

    @Test
    void cryptoThrowsOnShortWalletAddress() {
        PaymentStrategy strategy = new CryptoPaymentStrategy("0x123", "ETH");
        assertThrows(PaymentException.class, () -> strategy.pay(order));
    }

    @Test
    void cryptoThrowsOnEmptyCurrency() {
        PaymentStrategy strategy = new CryptoPaymentStrategy("0xABCDEF1234567890", "");
        assertThrows(PaymentException.class, () -> strategy.pay(order));
    }
}
