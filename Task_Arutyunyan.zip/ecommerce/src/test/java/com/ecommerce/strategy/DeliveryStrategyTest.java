package com.ecommerce.strategy;

import com.ecommerce.entity.*;
import com.ecommerce.exception.OrderException;
import com.ecommerce.strategy.delivery.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DeliveryStrategyTest {

    private Order order;

    @BeforeEach
    void setUp() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 10));
        order = new Order("ORD-1", customer, products, OrderType.REGULAR, LocalDateTime.now());
    }

    // --- Standard ---

    @Test
    void standardDeliverySetsDeliveryMethod() throws OrderException {
        DeliveryStrategy strategy = new StandardDeliveryStrategy();
        strategy.deliver(order);
        assertEquals("Стандартная", order.getDeliveryMethod());
    }

    @Test
    void standardDeliveryHasPositiveCost() {
        DeliveryStrategy strategy = new StandardDeliveryStrategy();
        assertTrue(strategy.getDeliveryCost() > 0);
    }

    @Test
    void standardDeliveryReturnsMethodName() {
        assertEquals("Стандартная", new StandardDeliveryStrategy().getMethodName());
    }

    @Test
    void standardDeliveryThrowsOnNullOrder() {
        DeliveryStrategy strategy = new StandardDeliveryStrategy();
        assertThrows(OrderException.class, () -> strategy.deliver(null));
    }

    // --- Express ---

    @Test
    void expressDeliverySetsDeliveryMethod() throws OrderException {
        DeliveryStrategy strategy = new ExpressDeliveryStrategy();
        strategy.deliver(order);
        assertEquals("Экспресс", order.getDeliveryMethod());
    }

    @Test
    void expressDeliveryIsMoreExpensiveThanStandard() {
        double standard = new StandardDeliveryStrategy().getDeliveryCost();
        double express = new ExpressDeliveryStrategy().getDeliveryCost();
        assertTrue(express > standard);
    }

    @Test
    void expressDeliveryThrowsOnNullOrder() {
        DeliveryStrategy strategy = new ExpressDeliveryStrategy();
        assertThrows(OrderException.class, () -> strategy.deliver(null));
    }

    // --- Digital ---

    @Test
    void digitalDeliverySetsDeliveryMethod() throws OrderException {
        DeliveryStrategy strategy = new DigitalDeliveryStrategy();
        strategy.deliver(order);
        assertEquals("Электронная", order.getDeliveryMethod());
    }

    @Test
    void digitalDeliveryIsZeroCost() {
        DeliveryStrategy strategy = new DigitalDeliveryStrategy();
        assertEquals(0.0, strategy.getDeliveryCost(), 0.001);
    }

    @Test
    void digitalDeliveryThrowsOnNullOrder() {
        DeliveryStrategy strategy = new DigitalDeliveryStrategy();
        assertThrows(OrderException.class, () -> strategy.deliver(null));
    }
}
