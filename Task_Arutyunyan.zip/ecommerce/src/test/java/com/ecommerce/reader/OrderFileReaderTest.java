package com.ecommerce.reader;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderType;
import com.ecommerce.entity.PreOrder;
import com.ecommerce.entity.Subscription;
import com.ecommerce.exception.FileReadException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderFileReaderTest {

    private OrderFileReader reader;

    @BeforeEach
    void setUp() {
        reader = new OrderFileReader();
    }

    @Test
    void readFromClasspathLoadsValidOrders() throws FileReadException {
        List<Order> orders = reader.readFromClasspath("data/test_orders.txt");
        assertFalse(orders.isEmpty(), "Should load at least one valid order");
    }

    @Test
    void readFromClasspathSkipsMalformedLines() throws FileReadException {
        List<Order> orders = reader.readFromClasspath("data/test_orders.txt");
        // File has 4 valid lines and 2 bad lines — expect exactly 4
        assertEquals(4, orders.size(),
                "Should load 4 valid orders, skipping malformed lines");
    }

    @Test
    void readFromClasspathParsesRegularOrder() throws FileReadException {
        List<Order> orders = reader.readFromClasspath("data/test_orders.txt");
        Order regular = orders.stream()
                .filter(o -> o.getOrderType() == OrderType.REGULAR)
                .findFirst()
                .orElse(null);
        assertNotNull(regular);
        assertEquals("Т-001", regular.getOrderId());
    }

    @Test
    void readFromClasspathParsesPreOrder() throws FileReadException {
        List<Order> orders = reader.readFromClasspath("data/test_orders.txt");
        Order preOrder = orders.stream()
                .filter(o -> o instanceof PreOrder)
                .findFirst()
                .orElse(null);
        assertNotNull(preOrder, "PreOrder should be parsed");
        assertEquals(OrderType.PRE_ORDER, preOrder.getOrderType());
    }

    @Test
    void readFromClasspathParsesSubscription() throws FileReadException {
        List<Order> orders = reader.readFromClasspath("data/test_orders.txt");
        Order sub = orders.stream()
                .filter(o -> o instanceof Subscription)
                .findFirst()
                .orElse(null);
        assertNotNull(sub, "Subscription should be parsed");
        assertEquals(30, ((Subscription) sub).getIntervalDays());
        assertEquals(6, ((Subscription) sub).getRenewalsLeft());
    }

    @Test
    void readFromClasspathThrowsForMissingResource() {
        assertThrows(FileReadException.class,
                () -> reader.readFromClasspath("data/nonexistent.txt"));
    }

    @Test
    void readFromPathThrowsForMissingFile(@TempDir Path tempDir) {
        Path missing = tempDir.resolve("missing.txt");
        assertThrows(FileReadException.class, () -> reader.readFromPath(missing));
    }

    @Test
    void readFromPathHandlesEmptyFile(@TempDir Path tempDir) throws IOException, FileReadException {
        Path emptyFile = tempDir.resolve("empty.txt");
        Files.writeString(emptyFile, "");
        List<Order> orders = reader.readFromPath(emptyFile);
        assertTrue(orders.isEmpty());
    }

    @Test
    void readFromPathHandlesOnlyComments(@TempDir Path tempDir) throws IOException, FileReadException {
        Path commentFile = tempDir.resolve("comments.txt");
        Files.writeString(commentFile, "# This is a comment\n# Another comment\n");
        List<Order> orders = reader.readFromPath(commentFile);
        assertTrue(orders.isEmpty());
    }

    @Test
    void readFromPathSkipsAllInvalidLines(@TempDir Path tempDir) throws IOException, FileReadException {
        Path badFile = tempDir.resolve("bad.txt");
        Files.writeString(badFile,
                "INVALID_TYPE;X;Y;Z;bad@email;Short;P:I:bad:1\n"
                + "REGULAR;;C1;No;no@email.com;Short;P1:Item:9.99:5\n");
        List<Order> orders = reader.readFromPath(badFile);
        assertTrue(orders.isEmpty(), "All lines are malformed, expect empty result");
    }

    @Test
    void readFromPathParsesValidLineFromFile(@TempDir Path tempDir) throws IOException, FileReadException {
        Path file = tempDir.resolve("single.txt");
        Files.writeString(file,
                "REGULAR;ORD-TEST;C1;Alice Smith;alice@test.com;123 Main Street Warsaw Poland;"
                + "P1:Widget:9.99:10\n");
        List<Order> orders = reader.readFromPath(file);
        assertEquals(1, orders.size());
        assertEquals("ORD-TEST", orders.get(0).getOrderId());
    }

    @Test
    void readFromPathParsesMultipleProductsInSingleOrder(@TempDir Path tempDir)
            throws IOException, FileReadException {
        Path file = tempDir.resolve("multi.txt");
        Files.writeString(file,
                "REGULAR;ORD-MP;C1;Alice Smith;alice@test.com;123 Main Street Warsaw Poland;"
                + "P1:Widget:9.99:10,P2:Gadget:49.99:5\n");
        List<Order> orders = reader.readFromPath(file);
        assertEquals(1, orders.size());
        assertEquals(2, orders.get(0).getProducts().size());
    }

    @Test
    void readFromPathMixOfValidAndInvalidLines(@TempDir Path tempDir)
            throws IOException, FileReadException {
        Path file = tempDir.resolve("mixed.txt");
        Files.writeString(file,
                "REGULAR;ORD-001;C1;Alice Smith;alice@test.com;123 Main Street Warsaw Poland;P1:Widget:9.99:10\n"
                + "BROKEN LINE WITH NO SEMICOLONS\n"
                + "REGULAR;ORD-002;C2;Bob Jones;bob@test.com;456 Oak Avenue Krakow Poland;P2:Gadget:49.99:5\n");
        List<Order> orders = reader.readFromPath(file);
        assertEquals(2, orders.size());
    }
}
