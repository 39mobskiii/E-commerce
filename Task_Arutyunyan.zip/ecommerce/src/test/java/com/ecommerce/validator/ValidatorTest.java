package com.ecommerce.validator;

import com.ecommerce.entity.*;
import com.ecommerce.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ValidatorTest {

    private OrderDataValidator dataValidator;
    private OrderResultValidator resultValidator;

    @BeforeEach
    void setUp() {
        dataValidator = new OrderDataValidator();
        resultValidator = new OrderResultValidator();
    }

    // --- OrderDataValidator: validateOrderId ---

    @Test
    void validateOrderIdPassesForValidId() {
        assertDoesNotThrow(() -> dataValidator.validateOrderId("ORD-001"));
    }

    @Test
    void validateOrderIdThrowsForNull() {
        assertThrows(ValidationException.class, () -> dataValidator.validateOrderId(null));
    }

    @Test
    void validateOrderIdThrowsForEmpty() {
        assertThrows(ValidationException.class, () -> dataValidator.validateOrderId(""));
    }

    @Test
    void validateOrderIdThrowsForTooShort() {
        assertThrows(ValidationException.class, () -> dataValidator.validateOrderId("XY"));
    }

    // --- OrderDataValidator: validateCustomerName ---

    @Test
    void validateCustomerNamePassesForValidName() {
        assertDoesNotThrow(() -> dataValidator.validateCustomerName("Alice"));
    }

    @Test
    void validateCustomerNameThrowsForNull() {
        assertThrows(ValidationException.class, () -> dataValidator.validateCustomerName(null));
    }

    @Test
    void validateCustomerNameThrowsForSingleChar() {
        assertThrows(ValidationException.class, () -> dataValidator.validateCustomerName("X"));
    }

    // --- OrderDataValidator: validateEmail ---

    @Test
    void validateEmailPassesForValidEmail() {
        assertDoesNotThrow(() -> dataValidator.validateEmail("user@example.com"));
    }

    @Test
    void validateEmailThrowsForMissingAt() {
        assertThrows(ValidationException.class, () -> dataValidator.validateEmail("userexample.com"));
    }

    @Test
    void validateEmailThrowsForMissingDot() {
        assertThrows(ValidationException.class, () -> dataValidator.validateEmail("user@examplecom"));
    }

    @Test
    void validateEmailThrowsForNull() {
        assertThrows(ValidationException.class, () -> dataValidator.validateEmail(null));
    }

    // --- OrderDataValidator: validateAddress ---

    @Test
    void validateAddressPassesForValidAddress() {
        assertDoesNotThrow(() -> dataValidator.validateAddress("123 Main Street Warsaw"));
    }

    @Test
    void validateAddressThrowsForTooShort() {
        assertThrows(ValidationException.class, () -> dataValidator.validateAddress("Short"));
    }

    @Test
    void validateAddressThrowsForNull() {
        assertThrows(ValidationException.class, () -> dataValidator.validateAddress(null));
    }

    // --- OrderDataValidator: validateAndParsePrice ---

    @Test
    void validateAndParsePriceReturnsCorrectValue() throws ValidationException {
        double price = dataValidator.validateAndParsePrice("19.99");
        assertEquals(19.99, price, 0.001);
    }

    @Test
    void validateAndParsePriceThrowsForNegative() {
        assertThrows(ValidationException.class, () -> dataValidator.validateAndParsePrice("-5.0"));
    }

    @Test
    void validateAndParsePriceThrowsForZero() {
        assertThrows(ValidationException.class, () -> dataValidator.validateAndParsePrice("0.0"));
    }

    @Test
    void validateAndParsePriceThrowsForNonNumeric() {
        assertThrows(ValidationException.class, () -> dataValidator.validateAndParsePrice("abc"));
    }

    // --- OrderDataValidator: validateAndParsePositiveInt ---

    @Test
    void validateAndParsePositiveIntReturnsCorrectValue() throws ValidationException {
        int val = dataValidator.validateAndParsePositiveInt("10", "stock");
        assertEquals(10, val);
    }

    @Test
    void validateAndParsePositiveIntAcceptsZero() throws ValidationException {
        int val = dataValidator.validateAndParsePositiveInt("0", "renewals");
        assertEquals(0, val);
    }

    @Test
    void validateAndParsePositiveIntThrowsForNegative() {
        assertThrows(ValidationException.class,
                () -> dataValidator.validateAndParsePositiveInt("-1", "stock"));
    }

    @Test
    void validateAndParsePositiveIntThrowsForNonNumeric() {
        assertThrows(ValidationException.class,
                () -> dataValidator.validateAndParsePositiveInt("abc", "stock"));
    }

    // --- OrderDataValidator: validateAndParseOrderType ---

    @Test
    void validateAndParseOrderTypeReturnsRegular() throws ValidationException {
        assertEquals(OrderType.REGULAR, dataValidator.validateAndParseOrderType("REGULAR"));
    }

    @Test
    void validateAndParseOrderTypeIsCaseInsensitive() throws ValidationException {
        assertEquals(OrderType.SUBSCRIPTION, dataValidator.validateAndParseOrderType("subscription"));
    }

    @Test
    void validateAndParseOrderTypeThrowsForUnknown() {
        assertThrows(ValidationException.class,
                () -> dataValidator.validateAndParseOrderType("UNKNOWN_TYPE"));
    }

    // --- OrderResultValidator: validateOrderTotal ---

    @Test
    void validateOrderTotalPassesForPositiveTotal() {
        Customer customer = new Customer("C1", "Alice", "alice@test.com",
                "123 Main Street Warsaw Poland");
        Order order = new Order("ORD-1", customer,
                List.of(new Product("P1", "Item", 9.99, 5)),
                OrderType.REGULAR, LocalDateTime.now());
        order.setTotalAmount(19.99);
        assertDoesNotThrow(() -> resultValidator.validateOrderTotal(order));
    }

    @Test
    void validateOrderTotalThrowsForZeroTotal() {
        Customer customer = new Customer("C1", "Alice", "alice@test.com",
                "123 Main Street Warsaw Poland");
        Order order = new Order("ORD-1", customer,
                List.of(new Product("P1", "Item", 9.99, 5)),
                OrderType.REGULAR, LocalDateTime.now());
        order.setTotalAmount(0.0);
        assertThrows(ValidationException.class, () -> resultValidator.validateOrderTotal(order));
    }

    @Test
    void validateOrderTotalThrowsForNullOrder() {
        assertThrows(ValidationException.class, () -> resultValidator.validateOrderTotal(null));
    }

    @Test
    void validateOrderTotalThrowsForExcessiveAmount() {
        Customer customer = new Customer("C1", "Alice", "alice@test.com",
                "123 Main Street Warsaw Poland");
        Order order = new Order("ORD-1", customer,
                List.of(new Product("P1", "Item", 9.99, 5)),
                OrderType.REGULAR, LocalDateTime.now());
        order.setTotalAmount(2_000_000.0);
        assertThrows(ValidationException.class, () -> resultValidator.validateOrderTotal(order));
    }

    // --- OrderResultValidator: validateOrderCompleteness ---

    @Test
    void validateOrderCompletenessPassesForCompleteOrder() {
        Customer customer = new Customer("C1", "Alice", "alice@test.com",
                "123 Main Street Warsaw Poland");
        Order order = new Order("ORD-1", customer,
                List.of(new Product("P1", "Item", 9.99, 5)),
                OrderType.REGULAR, LocalDateTime.now());
        assertDoesNotThrow(() -> resultValidator.validateOrderCompleteness(order));
    }

    @Test
    void validateOrderCompletenessThrowsForNullOrder() {
        assertThrows(ValidationException.class,
                () -> resultValidator.validateOrderCompleteness(null));
    }
}
