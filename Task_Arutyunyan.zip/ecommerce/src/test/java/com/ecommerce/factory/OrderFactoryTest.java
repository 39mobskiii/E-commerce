package com.ecommerce.factory;

import com.ecommerce.entity.*;
import com.ecommerce.exception.OrderException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderFactoryTest {

    private Customer customer;
    private List<Product> products;

    @BeforeEach
    void setUp() {
        customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        products = List.of(new Product("P1", "Widget", 9.99, 10));
    }

    // --- RegularOrderFactory ---

    @Test
    void regularFactoryCreatesRegularOrder() throws OrderException {
        OrderFactory factory = new RegularOrderFactory();
        Order order = factory.createOrder("ORD-1", customer, products);
        assertEquals(OrderType.REGULAR, order.getOrderType());
        assertEquals("ORD-1", order.getOrderId());
    }

    @Test
    void regularFactoryThrowsOnNullOrderId() {
        OrderFactory factory = new RegularOrderFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder(null, customer, products));
    }

    @Test
    void regularFactoryThrowsOnEmptyOrderId() {
        OrderFactory factory = new RegularOrderFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("", customer, products));
    }

    @Test
    void regularFactoryThrowsOnNullCustomer() {
        OrderFactory factory = new RegularOrderFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("ORD-1", null, products));
    }

    @Test
    void regularFactoryThrowsOnEmptyProducts() {
        OrderFactory factory = new RegularOrderFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("ORD-1", customer, List.of()));
    }

    // --- PreOrderFactory ---

    @Test
    void preOrderFactoryCreatesPreOrder() throws OrderException {
        OrderFactory factory = new PreOrderFactory();
        Order order = factory.createOrder("PRE-1", customer, products,
                "2027-06-01T00:00:00");
        assertInstanceOf(PreOrder.class, order);
        assertEquals(OrderType.PRE_ORDER, order.getOrderType());
    }

    @Test
    void preOrderFactoryThrowsOnMissingDateParam() {
        OrderFactory factory = new PreOrderFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("PRE-1", customer, products));
    }

    @Test
    void preOrderFactoryThrowsOnInvalidDateFormat() {
        OrderFactory factory = new PreOrderFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("PRE-1", customer, products, "not-a-date"));
    }

    // --- SubscriptionFactory ---

    @Test
    void subscriptionFactoryCreatesSubscription() throws OrderException {
        OrderFactory factory = new SubscriptionFactory();
        Order order = factory.createOrder("SUB-1", customer, products, "30", "12");
        assertInstanceOf(Subscription.class, order);
        assertEquals(OrderType.SUBSCRIPTION, order.getOrderType());
        assertEquals(30, ((Subscription) order).getIntervalDays());
        assertEquals(12, ((Subscription) order).getRenewalsLeft());
    }

    @Test
    void subscriptionFactoryThrowsOnMissingParams() {
        OrderFactory factory = new SubscriptionFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("SUB-1", customer, products, "30"));
    }

    @Test
    void subscriptionFactoryThrowsOnNonNumericInterval() {
        OrderFactory factory = new SubscriptionFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("SUB-1", customer, products, "monthly", "12"));
    }

    @Test
    void subscriptionFactoryThrowsOnZeroInterval() {
        OrderFactory factory = new SubscriptionFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("SUB-1", customer, products, "0", "12"));
    }

    @Test
    void subscriptionFactoryThrowsOnNegativeRenewals() {
        OrderFactory factory = new SubscriptionFactory();
        assertThrows(OrderException.class,
                () -> factory.createOrder("SUB-1", customer, products, "30", "-1"));
    }

    // --- OrderFactoryProvider ---

    @Test
    void providerReturnsRegularFactory() throws OrderException {
        OrderFactoryProvider provider = new OrderFactoryProvider();
        assertInstanceOf(RegularOrderFactory.class, provider.getFactory(OrderType.REGULAR));
    }

    @Test
    void providerReturnsPreOrderFactory() throws OrderException {
        OrderFactoryProvider provider = new OrderFactoryProvider();
        assertInstanceOf(PreOrderFactory.class, provider.getFactory(OrderType.PRE_ORDER));
    }

    @Test
    void providerReturnsSubscriptionFactory() throws OrderException {
        OrderFactoryProvider provider = new OrderFactoryProvider();
        assertInstanceOf(SubscriptionFactory.class, provider.getFactory(OrderType.SUBSCRIPTION));
    }
}
