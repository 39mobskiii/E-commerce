package com.ecommerce.service;

import com.ecommerce.entity.*;
import com.ecommerce.exception.OrderException;
import com.ecommerce.exception.PaymentException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.observer.OrderEventPublisher;
import com.ecommerce.strategy.delivery.DigitalDeliveryStrategy;
import com.ecommerce.strategy.delivery.ExpressDeliveryStrategy;
import com.ecommerce.strategy.delivery.StandardDeliveryStrategy;
import com.ecommerce.strategy.payment.CreditCardPaymentStrategy;
import com.ecommerce.strategy.payment.PayPalPaymentStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    private OrderService service;
    private OrderEventPublisher publisher;
    private Order validOrder;

    @BeforeEach
    void setUp() {
        publisher = new OrderEventPublisher();
        service = new OrderService(publisher);

        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 10));
        validOrder = new Order("ORD-1", customer, products, OrderType.REGULAR, LocalDateTime.now());
    }

    @Test
    void processOrderSuccessfully() {
        assertDoesNotThrow(() -> service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice Smith"),
                new StandardDeliveryStrategy()));
    }

    @Test
    void processOrderSetsCorrectFinalStatus() throws Exception {
        service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice Smith"),
                new StandardDeliveryStrategy());
        assertEquals(OrderStatus.SHIPPED, validOrder.getStatus());
    }

    @Test
    void processOrderCalculatesCorrectTotal() throws Exception {
        service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice Smith"),
                new StandardDeliveryStrategy());
        // Product 9.99 + Standard delivery 5.99
        assertEquals(9.99 + 5.99, validOrder.getTotalAmount(), 0.001);
    }

    @Test
    void processOrderWithDigitalDeliveryHasZeroDeliveryCost() throws Exception {
        service.processOrder(
                validOrder,
                new PayPalPaymentStrategy("alice@paypal.com"),
                new DigitalDeliveryStrategy());
        assertEquals(9.99, validOrder.getTotalAmount(), 0.001);
    }

    @Test
    void processOrderWithExpressDelivery() throws Exception {
        service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice"),
                new ExpressDeliveryStrategy());
        assertEquals(9.99 + 19.99, validOrder.getTotalAmount(), 0.001);
    }

    @Test
    void processOrderNotifiesObservers() throws Exception {
        List<OrderStatus> receivedStatuses = new ArrayList<>();
        publisher.subscribe((o, s) -> receivedStatuses.add(s));

        service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice"),
                new StandardDeliveryStrategy());

        assertTrue(receivedStatuses.contains(OrderStatus.PENDING_PAYMENT));
        assertTrue(receivedStatuses.contains(OrderStatus.PAYMENT_CONFIRMED));
        assertTrue(receivedStatuses.contains(OrderStatus.SHIPPED));
    }

    @Test
    void processOrderFailsForOutOfStockProduct() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> outOfStock = List.of(new Product("P1", "OutOfStock", 9.99, 0));
        Order badOrder = new Order("ORD-2", customer, outOfStock, OrderType.REGULAR,
                LocalDateTime.now());

        assertThrows(ValidationException.class, () -> service.processOrder(
                badOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice"),
                new StandardDeliveryStrategy()));
    }

    @Test
    void processOrderFailsForInvalidPayment() {
        assertThrows(PaymentException.class, () -> service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("123", "Alice"), // invalid card
                new StandardDeliveryStrategy()));
    }

    @Test
    void processOrderFailsForShortAddress() {
        Customer shortAddr = new Customer("C2", "Bob Jones", "bob@test.com", "Short");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 5));
        Order badOrder = new Order("ORD-3", shortAddr, products, OrderType.REGULAR,
                LocalDateTime.now());

        assertThrows(ValidationException.class, () -> service.processOrder(
                badOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Bob Jones"),
                new StandardDeliveryStrategy()));
    }

    @Test
    void cancelOrderSetsCancelledStatus() {
        service.cancelOrder(validOrder);
        assertEquals(OrderStatus.CANCELLED, validOrder.getStatus());
    }

    @Test
    void cancelOrderNotifiesObservers() {
        List<OrderStatus> receivedStatuses = new ArrayList<>();
        publisher.subscribe((o, s) -> receivedStatuses.add(s));

        service.cancelOrder(validOrder);

        assertTrue(receivedStatuses.contains(OrderStatus.CANCELLED));
    }

    @Test
    void processOrderWithMultipleProducts() throws Exception {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(
                new Product("P1", "Widget", 9.99, 10),
                new Product("P2", "Gadget", 49.99, 5));
        Order multiOrder = new Order("ORD-4", customer, products, OrderType.REGULAR,
                LocalDateTime.now());

        service.processOrder(
                multiOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice"),
                new DigitalDeliveryStrategy());

        // 9.99 + 49.99 + 0 (digital)
        assertEquals(59.98, multiOrder.getTotalAmount(), 0.001);
    }

    @Test
    void processOrderSetsPaymentMethod() throws Exception {
        service.processOrder(
                validOrder,
                new PayPalPaymentStrategy("alice@paypal.com"),
                new StandardDeliveryStrategy());
        assertEquals("PayPal", validOrder.getPaymentMethod());
    }

    @Test
    void processOrderSetsDeliveryMethod() throws Exception {
        service.processOrder(
                validOrder,
                new CreditCardPaymentStrategy("4111111111111111", "Alice"),
                new ExpressDeliveryStrategy());
        assertEquals("Экспресс", validOrder.getDeliveryMethod());
    }
}
