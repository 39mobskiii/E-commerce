package com.ecommerce.chain;

import com.ecommerce.entity.*;
import com.ecommerce.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ChainOfResponsibilityTest {

    private Order validOrder;

    @BeforeEach
    void setUp() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 5));
        validOrder = new Order("ORD-1", customer, products, OrderType.REGULAR, LocalDateTime.now());
        validOrder.setPaymentMethod("CreditCard");
        validOrder.setTotalAmount(19.99);
    }

    private ValidationHandler buildFullChain() {
        StockValidationHandler stock = new StockValidationHandler();
        PaymentValidationHandler payment = new PaymentValidationHandler();
        AddressValidationHandler address = new AddressValidationHandler();
        stock.setNext(payment).setNext(address);
        return stock;
    }

    // --- Full chain passes for valid order ---

    @Test
    void fullChainPassesForValidOrder() {
        assertDoesNotThrow(() -> buildFullChain().validate(validOrder));
    }

    // --- StockValidationHandler ---

    @Test
    void stockHandlerFailsWhenProductOutOfStock() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "OutOfStock", 9.99, 0));
        Order order = new Order("ORD-2", customer, products, OrderType.REGULAR, LocalDateTime.now());
        order.setPaymentMethod("CreditCard");
        order.setTotalAmount(9.99);

        StockValidationHandler handler = new StockValidationHandler();
        assertThrows(ValidationException.class, () -> handler.validate(order));
    }

    @Test
    void stockHandlerPassesWhenProductInStock() {
        StockValidationHandler handler = new StockValidationHandler();
        assertDoesNotThrow(() -> handler.validate(validOrder));
    }

    // --- PaymentValidationHandler ---

    @Test
    void paymentHandlerFailsWhenNoPaymentMethod() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 5));
        Order order = new Order("ORD-3", customer, products, OrderType.REGULAR, LocalDateTime.now());
        order.setTotalAmount(9.99);
        // paymentMethod intentionally not set

        PaymentValidationHandler handler = new PaymentValidationHandler();
        assertThrows(ValidationException.class, () -> handler.validate(order));
    }

    @Test
    void paymentHandlerFailsWhenTotalIsZero() {
        validOrder.setTotalAmount(0.0);
        PaymentValidationHandler handler = new PaymentValidationHandler();
        assertThrows(ValidationException.class, () -> handler.validate(validOrder));
    }

    @Test
    void paymentHandlerFailsWhenTotalIsNegative() {
        validOrder.setTotalAmount(-5.0);
        PaymentValidationHandler handler = new PaymentValidationHandler();
        assertThrows(ValidationException.class, () -> handler.validate(validOrder));
    }

    @Test
    void paymentHandlerPassesWithValidPayment() {
        PaymentValidationHandler handler = new PaymentValidationHandler();
        assertDoesNotThrow(() -> handler.validate(validOrder));
    }

    // --- AddressValidationHandler ---

    @Test
    void addressHandlerFailsWhenAddressTooShort() {
        Customer shortAddr = new Customer("C2", "Bob Jones", "bob@test.com", "Short");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 5));
        Order order = new Order("ORD-4", shortAddr, products, OrderType.REGULAR, LocalDateTime.now());
        order.setPaymentMethod("CreditCard");
        order.setTotalAmount(9.99);

        AddressValidationHandler handler = new AddressValidationHandler();
        assertThrows(ValidationException.class, () -> handler.validate(order));
    }

    @Test
    void addressHandlerPassesWithValidAddress() {
        AddressValidationHandler handler = new AddressValidationHandler();
        assertDoesNotThrow(() -> handler.validate(validOrder));
    }

    // --- Chain stops at first failure ---

    @Test
    void chainStopsAtStockFailureBeforePaymentCheck() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "OutOfStock", 9.99, 0));
        Order order = new Order("ORD-5", customer, products, OrderType.REGULAR, LocalDateTime.now());
        // Payment intentionally not set — but stock should fail first

        ValidationHandler chain = buildFullChain();
        ValidationException ex = assertThrows(ValidationException.class, () -> chain.validate(order));
        assertTrue(ex.getMessage().toLowerCase().contains("stock")
                || ex.getMessage().toLowerCase().contains("out of stock"));
    }

    // --- Chaining via setNext returns next handler ---

    @Test
    void setNextReturnsNextHandler() {
        StockValidationHandler stock = new StockValidationHandler();
        PaymentValidationHandler payment = new PaymentValidationHandler();
        ValidationHandler returned = stock.setNext(payment);
        assertSame(payment, returned);
    }
}
