package com.ecommerce.proxy;

import com.ecommerce.entity.Product;
import com.ecommerce.exception.OrderException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProxyTest {

    private RealProductRepository real;
    private CachingProductRepositoryProxy proxy;
    private Product product;

    @BeforeEach
    void setUp() {
        real = new RealProductRepository();
        proxy = new CachingProductRepositoryProxy(real);
        product = new Product("P1", "Widget", 9.99, 10);
        real.save(product);
    }

    @Test
    void proxyFetchesFromRealRepositoryOnFirstAccess() throws OrderException {
        Product found = proxy.findById("P1");
        assertEquals(product, found);
    }

    @Test
    void proxyReturnsCachedProductOnSecondAccess() throws OrderException {
        proxy.findById("P1");
        // Second call should hit cache — no exception, same product returned
        Product cached = proxy.findById("P1");
        assertEquals(product, cached);
    }

    @Test
    void cacheSizeIncreasesAfterFirstFetch() throws OrderException {
        assertEquals(0, proxy.getCacheSize());
        proxy.findById("P1");
        assertEquals(1, proxy.getCacheSize());
    }

    @Test
    void cacheSizeDoesNotDoubleOnRepeatFetch() throws OrderException {
        proxy.findById("P1");
        proxy.findById("P1");
        assertEquals(1, proxy.getCacheSize());
    }

    @Test
    void saveAlsoCachesProduct() {
        Product newProduct = new Product("P2", "Gadget", 49.99, 5);
        proxy.save(newProduct);
        assertEquals(1, proxy.getCacheSize());
    }

    @Test
    void invalidateRemovesFromCache() throws OrderException {
        proxy.findById("P1");
        proxy.invalidate("P1");
        assertEquals(0, proxy.getCacheSize());
    }

    @Test
    void clearCacheRemovesAllEntries() throws OrderException {
        Product p2 = new Product("P2", "Gadget", 49.99, 5);
        real.save(p2);
        proxy.findById("P1");
        proxy.findById("P2");
        assertEquals(2, proxy.getCacheSize());

        proxy.clearCache();
        assertEquals(0, proxy.getCacheSize());
    }

    @Test
    void proxyThrowsWhenProductNotFound() {
        assertThrows(OrderException.class, () -> proxy.findById("NONEXISTENT"));
    }

    @Test
    void realRepositoryThrowsWhenProductNotFound() {
        assertThrows(OrderException.class, () -> real.findById("NONEXISTENT"));
    }

    @Test
    void multipleDifferentProductsCachedSeparately() throws OrderException {
        Product p2 = new Product("P2", "Gadget", 49.99, 5);
        real.save(p2);

        proxy.findById("P1");
        proxy.findById("P2");

        assertEquals(2, proxy.getCacheSize());
        assertEquals(product, proxy.findById("P1"));
        assertEquals(p2, proxy.findById("P2"));
    }
}
