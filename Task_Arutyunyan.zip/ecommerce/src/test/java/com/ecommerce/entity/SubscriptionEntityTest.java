package com.ecommerce.entity;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SubscriptionEntityTest {

    private Customer sampleCustomer() {
        return new Customer("C1", "Alice Smith", "alice@test.com", "123 Main Street Warsaw Poland");
    }

    private List<Product> sampleProducts() {
        return List.of(new Product("P1", "MonthlyBox", 24.99, 100));
    }

    @Test
    void subscriptionHasCorrectType() {
        Subscription s = new Subscription("SUB-1", sampleCustomer(), sampleProducts(),
                LocalDateTime.now(), 30, 12);
        assertEquals(OrderType.SUBSCRIPTION, s.getOrderType());
    }

    @Test
    void subscriptionStoresIntervalAndRenewals() {
        Subscription s = new Subscription("SUB-1", sampleCustomer(), sampleProducts(),
                LocalDateTime.now(), 30, 12);
        assertEquals(30, s.getIntervalDays());
        assertEquals(12, s.getRenewalsLeft());
    }

    @Test
    void subscriptionEqualsWithSameFields() {
        LocalDateTime now = LocalDateTime.now();
        Subscription s1 = new Subscription("SUB-1", sampleCustomer(), sampleProducts(), now, 30, 12);
        Subscription s2 = new Subscription("SUB-1", sampleCustomer(), sampleProducts(), now, 30, 12);
        assertEquals(s1, s2);
        assertEquals(s1.hashCode(), s2.hashCode());
    }

    @Test
    void subscriptionNotEqualDifferentInterval() {
        LocalDateTime now = LocalDateTime.now();
        Subscription s1 = new Subscription("SUB-1", sampleCustomer(), sampleProducts(), now, 30, 12);
        Subscription s2 = new Subscription("SUB-1", sampleCustomer(), sampleProducts(), now, 7, 12);
        assertNotEquals(s1, s2);
    }

    @Test
    void subscriptionToStringContainsInterval() {
        Subscription s = new Subscription("SUB-1", sampleCustomer(), sampleProducts(),
                LocalDateTime.now(), 30, 12);
        assertTrue(s.toString().contains("30"));
    }
}
