package com.ecommerce.entity;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderEntityTest {

    private Customer sampleCustomer() {
        return new Customer("C1", "Alice Smith", "alice@test.com", "123 Main Street Warsaw Poland");
    }

    private List<Product> sampleProducts() {
        return List.of(new Product("P1", "Widget", 9.99, 10));
    }

    @Test
    void orderConstructorSetsFieldsCorrectly() {
        Customer customer = sampleCustomer();
        List<Product> products = sampleProducts();
        LocalDateTime now = LocalDateTime.now();

        Order order = new Order("ORD-1", customer, products, OrderType.REGULAR, now);

        assertEquals("ORD-1", order.getOrderId());
        assertEquals(customer, order.getCustomer());
        assertEquals(OrderType.REGULAR, order.getOrderType());
        assertEquals(OrderStatus.CREATED, order.getStatus());
        assertEquals(now, order.getCreatedAt());
    }

    @Test
    void orderSetStatusUpdatesCorrectly() {
        Order order = new Order("ORD-2", sampleCustomer(), sampleProducts(),
                OrderType.REGULAR, LocalDateTime.now());
        order.setStatus(OrderStatus.SHIPPED);
        assertEquals(OrderStatus.SHIPPED, order.getStatus());
    }

    @Test
    void orderEqualsAndHashCode() {
        LocalDateTime now = LocalDateTime.now();
        Order o1 = new Order("ORD-3", sampleCustomer(), sampleProducts(), OrderType.REGULAR, now);
        Order o2 = new Order("ORD-3", sampleCustomer(), sampleProducts(), OrderType.REGULAR, now);
        Order o3 = new Order("ORD-4", sampleCustomer(), sampleProducts(), OrderType.REGULAR, now);

        assertEquals(o1, o2);
        assertEquals(o1.hashCode(), o2.hashCode());
        assertNotEquals(o1, o3);
    }

    @Test
    void orderToStringContainsId() {
        Order order = new Order("ORD-X", sampleCustomer(), sampleProducts(),
                OrderType.REGULAR, LocalDateTime.now());
        assertTrue(order.toString().contains("ORD-X"));
    }

    @Test
    void orderProductsListIsDefensiveCopy() {
        List<Product> products = new java.util.ArrayList<>(sampleProducts());
        Order order = new Order("ORD-5", sampleCustomer(), products, OrderType.REGULAR,
                LocalDateTime.now());
        products.clear();
        assertFalse(order.getProducts().isEmpty());
    }
}
