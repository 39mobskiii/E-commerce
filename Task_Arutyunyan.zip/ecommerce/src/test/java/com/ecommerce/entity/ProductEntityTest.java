package com.ecommerce.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductEntityTest {

    @Test
    void productConstructorSetsAllFields() {
        Product p = new Product("P1", "Widget", 9.99, 10);
        assertEquals("P1", p.getId());
        assertEquals("Widget", p.getName());
        assertEquals(9.99, p.getPrice(), 0.001);
        assertEquals(10, p.getStockQuantity());
    }

    @Test
    void productEqualsSymmetric() {
        Product p1 = new Product("P1", "Widget", 9.99, 10);
        Product p2 = new Product("P1", "Widget", 9.99, 10);
        assertEquals(p1, p2);
        assertEquals(p2, p1);
    }

    @Test
    void productEqualsDifferentIdNotEqual() {
        Product p1 = new Product("P1", "Widget", 9.99, 10);
        Product p2 = new Product("P2", "Widget", 9.99, 10);
        assertNotEquals(p1, p2);
    }

    @Test
    void productHashCodeConsistentWithEquals() {
        Product p1 = new Product("P1", "Widget", 9.99, 10);
        Product p2 = new Product("P1", "Widget", 9.99, 10);
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    void productToStringContainsName() {
        Product p = new Product("P1", "Widget", 9.99, 10);
        assertTrue(p.toString().contains("Widget"));
    }

    @Test
    void productNotEqualToNull() {
        Product p = new Product("P1", "Widget", 9.99, 10);
        assertNotEquals(null, p);
    }
}
