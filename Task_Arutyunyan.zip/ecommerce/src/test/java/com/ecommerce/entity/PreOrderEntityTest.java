package com.ecommerce.entity;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PreOrderEntityTest {

    private Customer sampleCustomer() {
        return new Customer("C1", "Alice Smith", "alice@test.com", "123 Main Street Warsaw Poland");
    }

    private List<Product> sampleProducts() {
        return List.of(new Product("P1", "Widget", 9.99, 0));
    }

    @Test
    void preOrderHasCorrectType() {
        LocalDateTime available = LocalDateTime.now().plusDays(30);
        PreOrder po = new PreOrder("PRE-1", sampleCustomer(), sampleProducts(),
                LocalDateTime.now(), available);
        assertEquals(OrderType.PRE_ORDER, po.getOrderType());
    }

    @Test
    void preOrderStoresAvailableFrom() {
        LocalDateTime available = LocalDateTime.of(2027, 6, 1, 0, 0);
        PreOrder po = new PreOrder("PRE-1", sampleCustomer(), sampleProducts(),
                LocalDateTime.now(), available);
        assertEquals(available, po.getAvailableFrom());
    }

    @Test
    void preOrderEqualsWithSameAvailableFrom() {
        LocalDateTime available = LocalDateTime.of(2027, 6, 1, 0, 0);
        LocalDateTime now = LocalDateTime.now();
        PreOrder p1 = new PreOrder("PRE-1", sampleCustomer(), sampleProducts(), now, available);
        PreOrder p2 = new PreOrder("PRE-1", sampleCustomer(), sampleProducts(), now, available);
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    void preOrderNotEqualDifferentAvailableFrom() {
        LocalDateTime now = LocalDateTime.now();
        PreOrder p1 = new PreOrder("PRE-1", sampleCustomer(), sampleProducts(),
                now, LocalDateTime.of(2027, 6, 1, 0, 0));
        PreOrder p2 = new PreOrder("PRE-1", sampleCustomer(), sampleProducts(),
                now, LocalDateTime.of(2028, 1, 1, 0, 0));
        assertNotEquals(p1, p2);
    }

    @Test
    void preOrderToStringContainsOrderId() {
        PreOrder po = new PreOrder("PRE-99", sampleCustomer(), sampleProducts(),
                LocalDateTime.now(), LocalDateTime.now().plusDays(10));
        assertTrue(po.toString().contains("PRE-99"));
    }
}
