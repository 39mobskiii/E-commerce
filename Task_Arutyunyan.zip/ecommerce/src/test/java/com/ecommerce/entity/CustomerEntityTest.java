package com.ecommerce.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerEntityTest {

    @Test
    void customerConstructorSetsAllFields() {
        Customer c = new Customer("C1", "Alice", "alice@test.com", "123 Main St Warsaw");
        assertEquals("C1", c.getId());
        assertEquals("Alice", c.getName());
        assertEquals("alice@test.com", c.getEmail());
        assertEquals("123 Main St Warsaw", c.getAddress());
    }

    @Test
    void customerEqualsAndHashCode() {
        Customer c1 = new Customer("C1", "Alice", "alice@test.com", "123 Main St Warsaw");
        Customer c2 = new Customer("C1", "Alice", "alice@test.com", "123 Main St Warsaw");
        assertEquals(c1, c2);
        assertEquals(c1.hashCode(), c2.hashCode());
    }

    @Test
    void customerDifferentEmailNotEqual() {
        Customer c1 = new Customer("C1", "Alice", "alice@test.com", "123 Main St Warsaw");
        Customer c2 = new Customer("C1", "Alice", "other@test.com", "123 Main St Warsaw");
        assertNotEquals(c1, c2);
    }

    @Test
    void customerToStringContainsEmail() {
        Customer c = new Customer("C1", "Alice", "alice@test.com", "123 Main St Warsaw");
        assertTrue(c.toString().contains("alice@test.com"));
    }
}
