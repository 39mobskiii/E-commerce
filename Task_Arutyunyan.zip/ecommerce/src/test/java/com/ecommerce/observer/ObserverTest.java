package com.ecommerce.observer;

import com.ecommerce.entity.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ObserverTest {

    private Order order;
    private OrderEventPublisher publisher;

    @BeforeEach
    void setUp() {
        Customer customer = new Customer("C1", "Alice Smith", "alice@test.com",
                "123 Main Street Warsaw Poland");
        List<Product> products = List.of(new Product("P1", "Widget", 9.99, 10));
        order = new Order("ORD-1", customer, products, OrderType.REGULAR, LocalDateTime.now());
        publisher = new OrderEventPublisher();
    }

    @Test
    void publisherStartsWithNoObservers() {
        assertEquals(0, publisher.getObserverCount());
    }

    @Test
    void subscribingAddsObserver() {
        publisher.subscribe(new CustomerNotificationObserver());
        assertEquals(1, publisher.getObserverCount());
    }

    @Test
    void subscribingNullDoesNothing() {
        publisher.subscribe(null);
        assertEquals(0, publisher.getObserverCount());
    }

    @Test
    void subscribingSameObserverTwiceAddedOnce() {
        OrderObserver obs = new CustomerNotificationObserver();
        publisher.subscribe(obs);
        publisher.subscribe(obs);
        assertEquals(1, publisher.getObserverCount());
    }

    @Test
    void unsubscribingRemovesObserver() {
        OrderObserver obs = new CustomerNotificationObserver();
        publisher.subscribe(obs);
        publisher.unsubscribe(obs);
        assertEquals(0, publisher.getObserverCount());
    }

    @Test
    void notifyObserversCallsAllSubscribers() {
        List<OrderStatus> received = new ArrayList<>();

        OrderObserver obs1 = (o, s) -> received.add(s);
        OrderObserver obs2 = (o, s) -> received.add(s);

        publisher.subscribe(obs1);
        publisher.subscribe(obs2);
        publisher.notifyObservers(order, OrderStatus.SHIPPED);

        assertEquals(2, received.size());
        assertTrue(received.stream().allMatch(s -> s == OrderStatus.SHIPPED));
    }

    @Test
    void notifyObserversPassesCorrectOrder() {
        List<Order> receivedOrders = new ArrayList<>();
        publisher.subscribe((o, s) -> receivedOrders.add(o));
        publisher.notifyObservers(order, OrderStatus.PROCESSING);
        assertEquals(1, receivedOrders.size());
        assertEquals("ORD-1", receivedOrders.get(0).getOrderId());
    }

    @Test
    void customerNotificationObserverDoesNotThrow() {
        OrderObserver obs = new CustomerNotificationObserver();
        assertDoesNotThrow(() -> obs.onStatusChanged(order, OrderStatus.DELIVERED));
    }

    @Test
    void warehouseObserverDoesNotThrow() {
        OrderObserver obs = new WarehouseObserver();
        assertDoesNotThrow(() -> obs.onStatusChanged(order, OrderStatus.PAYMENT_CONFIRMED));
        assertDoesNotThrow(() -> obs.onStatusChanged(order, OrderStatus.CANCELLED));
        assertDoesNotThrow(() -> obs.onStatusChanged(order, OrderStatus.SHIPPED));
    }

    @Test
    void analyticsObserverDoesNotThrow() {
        OrderObserver obs = new AnalyticsObserver();
        assertDoesNotThrow(() -> obs.onStatusChanged(order, OrderStatus.DELIVERED));
    }

    @Test
    void multipleObserversAllReceiveNotification() {
        int[] callCounts = {0, 0, 0};
        publisher.subscribe((o, s) -> callCounts[0]++);
        publisher.subscribe((o, s) -> callCounts[1]++);
        publisher.subscribe((o, s) -> callCounts[2]++);

        publisher.notifyObservers(order, OrderStatus.CREATED);

        assertEquals(1, callCounts[0]);
        assertEquals(1, callCounts[1]);
        assertEquals(1, callCounts[2]);
    }
}
